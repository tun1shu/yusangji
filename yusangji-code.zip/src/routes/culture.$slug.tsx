import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { getCultureArticle } from "@/lib/data.functions";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, BookOpen } from "lucide-react";
import ReactMarkdown from "react-markdown";

function articleQueryOptions(slug: string) {
  return queryOptions({
    queryKey: ["culture-article", slug],
    queryFn: () => getCultureArticle({ data: { slug } }),
  });
}

export const Route = createFileRoute("/culture/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: "文化文章 — 渔桑记" },
      { name: "description", content: "阅读渔桑文化科普文章。" },
      { property: "og:title", content: "文化文章 — 渔桑记" },
      { property: "og:description", content: "阅读渔桑文化科普文章。" },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: async ({ context, params }) => {
    const article = await context.queryClient.ensureQueryData(articleQueryOptions(params.slug));
    if (!article) throw notFound();
    return { article };
  },
  component: CultureDetailPage,
});

function CultureDetailPage() {
  const { slug } = Route.useParams();
  const { data: article } = useSuspenseQuery(articleQueryOptions(slug));

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <Button asChild variant="ghost" className="mb-6 -ml-3 rounded-full">
        <Link to="/culture">
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回文化列表
        </Link>
      </Button>

      <article className="overflow-hidden rounded-3xl bg-card shadow-sm">
        <div className="aspect-video w-full overflow-hidden bg-muted">
          <img
            src={article.cover_url || "https://placehold.co/1200x600/e2e8f0/64748b?text=暂无封面"}
            alt={article.title}
            className="h-full w-full object-cover"
          />
        </div>
        <div className="p-6 sm:p-10">
          <div className="mb-4 flex items-center gap-2">
            <div className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-leaf/10">
              <BookOpen className="h-4 w-4 text-leaf" />
            </div>
            {article.category && <Badge variant="secondary">{article.category}</Badge>}
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">{article.title}</h1>
          {article.summary && <p className="mt-3 text-lg text-muted-foreground">{article.summary}</p>}
          <Separator className="my-6" />
          <div className="prose prose-slate max-w-none dark:prose-invert">
            {article.content ? (
              <ReactMarkdown>{article.content}</ReactMarkdown>
            ) : (
              <p className="text-muted-foreground">暂无正文内容</p>
            )}
          </div>
        </div>
      </article>
    </div>
  );
}
