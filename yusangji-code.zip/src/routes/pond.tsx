import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Gamepad2 } from "lucide-react";
import { listFishSpecies } from "@/lib/data.functions";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FishSortGame } from "@/components/games/FishSortGame";
import { CycleGame } from "@/components/games/CycleGame";


const fishListQueryOptions = queryOptions({
  queryKey: ["fish-species"],
  queryFn: () => listFishSpecies(),
});

type GameTab = "sort" | "cycle";

export const Route = createFileRoute("/pond")({
  validateSearch: (search: Record<string, unknown>): { game?: GameTab } => {
    const g = search["game"];
    return g === "sort" || g === "cycle" ? { game: g } : {};
  },
  head: () => ({
    meta: [
      { title: "渔桑小游戏 — 渔桑记" },
      { name: "description", content: "两个轻松小游戏：认鱼分类挑战、桑基鱼塘与四大家鱼循环拼图，边玩边学渔桑文化。" },
      { property: "og:title", content: "渔桑小游戏 — 渔桑记" },
      {
        property: "og:description",
        content: "两个轻松小游戏：认鱼分类挑战、桑基鱼塘与四大家鱼循环拼图，边玩边学渔桑文化。",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(fishListQueryOptions),
  component: GamesPage,
});

function GamesPage() {
  const { data: species } = useSuspenseQuery(fishListQueryOptions);
  const { game } = Route.useSearch();
  const navigate = useNavigate({ from: "/pond" });

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
          <Gamepad2 className="h-6 w-6 text-primary" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">渔桑小游戏</h1>
        <p className="mt-2 text-muted-foreground">
          两个轻松小游戏，没有倒计时、答错可以重来，边玩边认识鱼类与桑基鱼塘
        </p>
      </div>

      <Tabs
        value={game ?? "sort"}
        onValueChange={(v) =>
          navigate({ search: { game: v as GameTab }, replace: true })
        }
      >
        <TabsList className="mb-6 grid w-full grid-cols-2">
          <TabsTrigger value="sort">认鱼分类</TabsTrigger>
          <TabsTrigger value="cycle">循环拼图</TabsTrigger>
        </TabsList>
        <TabsContent value="sort">
          <FishSortGame species={species} />
        </TabsContent>
        <TabsContent value="cycle">
          <CycleGame />
        </TabsContent>
      </Tabs>
    </div>
  );
}
