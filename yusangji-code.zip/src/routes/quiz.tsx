import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { listQuizQuestions } from "@/lib/data.functions";
import { QuizGame } from "@/components/QuizGame";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Trophy, AlertCircle } from "lucide-react";

const quizQueryOptions = queryOptions({
  queryKey: ["quiz-questions"],
  queryFn: () => listQuizQuestions({ data: { limit: 10 } }),
});

export const Route = createFileRoute("/quiz")({
  head: () => ({
    meta: [
      { title: "知识闯关 — 渔桑记" },
      { name: "description", content: "挑战渔桑文化知识问答，边玩边学。" },
      { property: "og:title", content: "知识闯关 — 渔桑记" },
      { property: "og:description", content: "挑战渔桑文化知识问答，边玩边学。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(quizQueryOptions),
  component: QuizPage,
});

function QuizPage() {
  const { data: questions } = useSuspenseQuery(quizQueryOptions);
  const { user } = useAuth();

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
          <Trophy className="h-6 w-6 text-primary" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">知识闯关</h1>
        <p className="mt-2 text-muted-foreground">答对题目，解锁渔桑小达人称号</p>
      </div>

      {!user && (
        <div className="mb-6 flex items-start gap-3 rounded-2xl border border-border bg-card p-4 text-sm text-muted-foreground">
          <AlertCircle className="h-5 w-5 flex-shrink-0 text-primary" />
          <div className="flex-1">
            登录后闯关成绩会被记录，方便你追踪学习进度。
            <Button asChild variant="link" size="sm" className="h-auto p-0">
              <Link to="/auth">去登录</Link>
            </Button>
          </div>
        </div>
      )}

      <QuizGame questions={questions} userId={user?.id ?? null} />
    </div>
  );
}
