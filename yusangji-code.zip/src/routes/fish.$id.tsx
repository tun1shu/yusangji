import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { getFishSpecies } from "@/lib/data.functions";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Fish, ArrowLeft, MapPin, Utensils, Sparkles } from "lucide-react";

function fishQueryOptions(id: string) {
  return queryOptions({
    queryKey: ["fish-species", id],
    queryFn: () => getFishSpecies({ data: { id } }),
  });
}

export const Route = createFileRoute("/fish/$id")({
  head: ({ params }) => ({
    meta: [
      { title: "鱼类详情 — 渔桑记" },
      { name: "description", content: "了解这条鱼的生活习性、食性和有趣知识。" },
      { property: "og:title", content: "鱼类详情 — 渔桑记" },
      { property: "og:description", content: "了解这条鱼的生活习性、食性和有趣知识。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: async ({ context, params }) => {
    const fish = await context.queryClient.ensureQueryData(fishQueryOptions(params.id));
    if (!fish) throw notFound();
    return { fish };
  },
  component: FishDetailPage,
});

function FishDetailPage() {
  const { id } = Route.useParams();
  const { data: fish } = useSuspenseQuery(fishQueryOptions(id));

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <Button asChild variant="ghost" className="mb-6 -ml-3 rounded-full">
        <Link to="/fish">
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回图鉴
        </Link>
      </Button>

      <div className="overflow-hidden rounded-3xl bg-card shadow-sm">
        <div className="aspect-video w-full overflow-hidden bg-muted">
          <img
            src={fish.image_url || "https://placehold.co/1200x600/e2e8f0/64748b?text=暂无图片"}
            alt={fish.name}
            className="h-full w-full object-cover"
          />
        </div>
        <div className="p-6 sm:p-10">
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-pond/10">
              <Fish className="h-5 w-5 text-pond" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">{fish.name}</h1>
              {fish.scientific_name && (
                <p className="text-sm italic text-muted-foreground">{fish.scientific_name}</p>
              )}
            </div>
          </div>

          <div className="mb-6 flex flex-wrap gap-2">
            {fish.category && <Badge variant="secondary">{fish.category}</Badge>}
            {fish.difficulty && (
              <Badge variant="outline">
                难度：{fish.difficulty === "easy" ? "简单" : fish.difficulty === "medium" ? "中等" : "挑战"}
              </Badge>
            )}
            {fish.aliases && fish.aliases.length > 0 && (
              <Badge variant="outline">别名：{fish.aliases.join("、")}</Badge>
            )}
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="bg-sand/40">
              <CardContent className="flex items-start gap-3 p-4">
                <MapPin className="mt-1 h-5 w-5 text-pond" />
                <div>
                  <p className="font-medium text-foreground">栖息地</p>
                  <p className="text-sm text-muted-foreground">{fish.habitat || "暂无信息"}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-sand/40">
              <CardContent className="flex items-start gap-3 p-4">
                <Utensils className="mt-1 h-5 w-5 text-leaf" />
                <div>
                  <p className="font-medium text-foreground">食性</p>
                  <p className="text-sm text-muted-foreground">{fish.diet || "暂无信息"}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Separator className="my-6" />

          <section className="mb-6">
            <h2 className="mb-2 text-xl font-bold text-foreground">简介</h2>
            <p className="leading-relaxed text-muted-foreground">{fish.description || "暂无简介"}</p>
          </section>

          {fish.fun_facts && fish.fun_facts.length > 0 && (
            <section>
              <h2 className="mb-3 flex items-center gap-2 text-xl font-bold text-foreground">
                <Sparkles className="h-5 w-5 text-primary" />
                趣味知识
              </h2>
              <ul className="space-y-2">
                {fish.fun_facts.map((fact, i) => (
                  <li key={i} className="flex items-start gap-2 rounded-xl bg-accent/40 p-3 text-foreground">
                    <span className="mt-0.5 inline-flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      {i + 1}
                    </span>
                    {fact}
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
