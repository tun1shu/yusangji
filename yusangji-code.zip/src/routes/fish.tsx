import { useMemo, useRef, useState } from "react";
import { FilterBar } from "@/components/FilterBar";
import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { listFishSpecies } from "@/lib/data.functions";
import { FishCard, FishDetail, fishImage } from "@/components/FishCard";
import { KnowledgeDialog } from "@/components/KnowledgeDialog";
import { Button } from "@/components/ui/button";
import { FavoriteButton } from "@/components/FavoriteButton";
import { Fish as FishIcon, SearchX } from "lucide-react";

const fishListQueryOptions = queryOptions({
  queryKey: ["fish-species"],
  queryFn: () => listFishSpecies(),
});

export const Route = createFileRoute("/fish")({
  head: () => ({
    meta: [
      { title: "鱼类图鉴 — 渔桑记" },
      { name: "description", content: "认识桑基鱼塘里常见的鱼类朋友，学习它们的习性与文化故事。" },
      { property: "og:title", content: "鱼类图鉴 — 渔桑记" },
      { property: "og:description", content: "认识桑基鱼塘里常见的鱼类朋友，学习它们的习性与文化故事。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(fishListQueryOptions),
  component: FishPage,
});

function FishPage() {
  const { data: fishList } = useSuspenseQuery(fishListQueryOptions);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("全部");
  const cardRefs = useRef<Array<HTMLDivElement | null>>([]);

  const categories = useMemo(
    () => Array.from(new Set(fishList.map((f) => f.category).filter(Boolean) as string[])),
    [fishList],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return fishList.filter((f) => {
      if (category !== "全部" && f.category !== category) return false;
      if (!q) return true;
      const haystack = [f.name, f.scientific_name, f.description, f.habitat, f.diet, ...(f.aliases || [])]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [fishList, query, category]);

  const active = activeIndex !== null ? filtered[activeIndex] : undefined;

  const handleClose = () => {
    const i = activeIndex;
    setActiveIndex(null);
    if (i === null) return;
    setTimeout(() => {
      const el = cardRefs.current[i];
      if (!el) return;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      el.classList.add("ring-2", "ring-pond", "rounded-xl");
      setTimeout(() => el.classList.remove("ring-2", "ring-pond", "rounded-xl"), 1600);
    }, 120);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-pond/10">
          <FishIcon className="h-6 w-6 text-pond" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">鱼类图鉴</h1>
        <p className="mt-2 text-muted-foreground">点击卡片，了解每条鱼的故事与生活习性</p>
      </div>

      <FilterBar
        query={query}
        onQueryChange={(v) => {
          setQuery(v);
          setActiveIndex(null);
        }}
        categories={categories}
        activeCategory={category}
        onCategoryChange={(v) => {
          setCategory(v);
          setActiveIndex(null);
        }}
        placeholder="搜索鱼名、别名或习性…"
        resultCount={filtered.length}
      />

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card py-16 text-center">
          <SearchX className="h-12 w-12 text-muted-foreground" />
          <p className="mt-4 text-muted-foreground">
            {fishList.length === 0 ? "暂无鱼类数据" : "没有找到匹配的鱼类，换个关键词试试"}
          </p>
          <Button asChild variant="outline" className="mt-4 rounded-full">
            <Link to="/">回首页</Link>
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((fish, i) => (
            <div
              key={fish.id}
              ref={(el) => {
                cardRefs.current[i] = el;
              }}
              className="transition-shadow"
            >
              <FishCard fish={fish} onOpen={() => setActiveIndex(i)} />
            </div>
          ))}
        </div>
      )}


      {active && activeIndex !== null && (
        <KnowledgeDialog
          open
          index={activeIndex}
          total={fishList.length}
          title={active.name}
          subtitle={active.scientific_name}
          image={fishImage(active)}
          onIndexChange={setActiveIndex}
          onClose={handleClose}
          footer={
            <>
              <FavoriteButton targetId={active.id} targetType="fish" />
              <Button asChild className="flex-1 rounded-full">
                <Link to="/fish/$id" params={{ id: active.id }}>
                  查看完整详情页
                </Link>
              </Button>
            </>
          }
        >
          <FishDetail fish={active} />
        </KnowledgeDialog>
      )}
    </div>
  );
}

