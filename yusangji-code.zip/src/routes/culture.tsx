import { useMemo, useRef, useState } from "react";
import { FilterBar } from "@/components/FilterBar";
import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { listCultureArticles } from "@/lib/data.functions";
import { ArticleCard, ArticleDetail, articleCover } from "@/components/ArticleCard";
import { KnowledgeDialog } from "@/components/KnowledgeDialog";
import { Button } from "@/components/ui/button";
import { FavoriteButton } from "@/components/FavoriteButton";
import { BookOpen, SearchX } from "lucide-react";

const articlesQueryOptions = queryOptions({
  queryKey: ["culture-articles"],
  queryFn: () => listCultureArticles(),
});

export const Route = createFileRoute("/culture")({
  head: () => ({
    meta: [
      { title: "桑基鱼塘文化 — 渔桑记" },
      { name: "description", content: "探索千年桑基鱼塘的生态智慧与人文故事。" },
      { property: "og:title", content: "桑基鱼塘文化 — 渔桑记" },
      { property: "og:description", content: "探索千年桑基鱼塘的生态智慧与人文故事。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(articlesQueryOptions),
  component: CulturePage,
});

function CulturePage() {
  const { data: articles } = useSuspenseQuery(articlesQueryOptions);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("全部");
  const cardRefs = useRef<Array<HTMLDivElement | null>>([]);

  const categories = useMemo(
    () => Array.from(new Set(articles.map((a) => a.category).filter(Boolean) as string[])),
    [articles],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return articles.filter((a) => {
      if (category !== "全部" && a.category !== category) return false;
      if (!q) return true;
      const haystack = [a.title, a.summary, a.content].filter(Boolean).join(" ").toLowerCase();
      return haystack.includes(q);
    });
  }, [articles, query, category]);

  const active = activeIndex !== null ? filtered[activeIndex] : undefined;

  const handleClose = () => {
    const i = activeIndex;
    setActiveIndex(null);
    if (i === null) return;
    setTimeout(() => {
      const el = cardRefs.current[i];
      if (!el) return;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      el.classList.add("ring-2", "ring-leaf", "rounded-xl");
      setTimeout(() => el.classList.remove("ring-2", "ring-leaf", "rounded-xl"), 1600);
    }, 120);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-leaf/10">
          <BookOpen className="h-6 w-6 text-leaf" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">桑基鱼塘文化</h1>
        <p className="mt-2 text-muted-foreground">读懂“桑—蚕—鱼—泥”的生态循环智慧</p>
      </div>

      <FilterBar
        query={query}
        onQueryChange={(v) => {
          setQuery(v);
          setActiveIndex(null);
        }}
        categories={categories}
        activeCategory={category}
        onCategoryChange={(v) => {
          setCategory(v);
          setActiveIndex(null);
        }}
        placeholder="搜索文章标题或内容…"
        resultCount={filtered.length}
      />

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card py-16 text-center">
          <SearchX className="h-12 w-12 text-muted-foreground" />
          <p className="mt-4 text-muted-foreground">
            {articles.length === 0 ? "暂无文化文章" : "没有找到匹配的内容，换个关键词试试"}
          </p>
          <Button asChild variant="outline" className="mt-4 rounded-full">
            <Link to="/">回首页</Link>
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((article, i) => (
            <div
              key={article.id}
              ref={(el) => {
                cardRefs.current[i] = el;
              }}
              className="transition-shadow"
            >
              <ArticleCard article={article} onOpen={() => setActiveIndex(i)} />
            </div>
          ))}
        </div>
      )}


      {active && activeIndex !== null && (
        <KnowledgeDialog
          open
          index={activeIndex}
          total={articles.length}
          title={active.title}
          subtitle={active.summary}
          image={articleCover(active)}
          onIndexChange={setActiveIndex}
          onClose={handleClose}
          footer={
            <>
              <FavoriteButton targetId={active.id} targetType="article" />
              <Button asChild className="flex-1 rounded-full">
                <Link to="/culture/$slug" params={{ slug: active.slug }}>
                  打开完整文章页
                </Link>
              </Button>
            </>
          }
        >
          <ArticleDetail article={active} />
        </KnowledgeDialog>
      )}
    </div>
  );
}

