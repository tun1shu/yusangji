import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Leaf, ArrowRight } from "lucide-react";
import yuXiaoQing from "@/assets/yuxiaoqing.jpg.asset.json";
import sangXiaoCan from "@/assets/sangxiaocan.png.asset.json";
import modFish from "@/assets/mod-fish.jpg.asset.json";
import modCulture from "@/assets/mod-culture.jpg.asset.json";
import modQuiz from "@/assets/mod-quiz.jpg.asset.json";
import modGame from "@/assets/mod-game.jpg.asset.json";
import modAi from "@/assets/mod-ai.jpg.asset.json";
import modCheckin from "@/assets/mod-checkin.jpg.asset.json";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "渔桑记 — 渔小青与桑小蚕带你探索渔桑文化" },
      { name: "description", content: "渔桑记为中小学生打造：鱼类图鉴、桑基鱼塘文化、知识闯关、渔桑小游戏、学习打卡与 AI 科普助手。" },
      { property: "og:title", content: "渔桑记 — 渔小青与桑小蚕带你探索渔桑文化" },
      { property: "og:description", content: "桑蚕育乡土，青鱼守水乡。跟随双 IP 形象走进桑基鱼塘的生态智慧。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});


const features = [
  {
    to: "/fish",
    img: modFish.url,
    title: "鱼类图鉴",
    desc: "认识草鱼、鲫鱼、鲤鱼等常见淡水鱼，了解它们的生活习性与文化故事。",
    bg: "bg-pond/10",
  },
  {
    to: "/culture",
    img: modCulture.url,
    title: "桑基鱼塘",
    desc: "探索千年生态循环农业智慧，从桑叶、蚕沙到塘泥的奇妙循环。",
    bg: "bg-leaf/10",
  },
  {
    to: "/quiz",
    img: modQuiz.url,
    title: "知识闯关",
    desc: "趣味问答挑战，边玩边学，检验你对渔桑文化的了解。",
    bg: "bg-primary/10",
  },
  {
    to: "/pond",
    search: { game: "sort" as const },
    img: modGame.url,
    title: "渔桑小游戏",
    desc: "认鱼分类、循环拼图，两个轻松小游戏边玩边学。",
    bg: "bg-blue-500/10",
  },
  {
    to: "/ai-assistant",
    img: modAi.url,
    title: "AI 助手",
    desc: "有问题？随时向渔小青、桑小蚕的 AI 伙伴提问。",
    bg: "bg-purple-500/10",
  },
  {
    to: "/checkin",
    img: modCheckin.url,
    title: "学习打卡",
    desc: "每天学习一点点，记录成长足迹，养成好习惯。",
    bg: "bg-orange-500/10",
  },
];


function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-sand via-background to-pond/20 px-4 py-16 sm:py-24 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <Leaf className="h-4 w-4" />
                <span>面向中小学生的美育科普平台</span>
              </div>
              <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
                渔桑记
                <span className="block text-primary">探索渔桑文化之美</span>
              </h1>
              <p className="max-w-xl text-lg text-muted-foreground">
                跟随渔小青与桑小蚕，走进桑基鱼塘的生态圈，认识水中朋友，感受传统农业智慧与自然和谐之美。
              </p>
              <div className="flex flex-wrap gap-3">
                <Button asChild size="lg" className="rounded-full">
                  <Link to="/fish">
                    开始探索 <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="rounded-full">
                  <Link to="/quiz">知识闯关</Link>
                </Button>
              </div>
            </div>
            <div className="relative mx-auto w-full max-w-md lg:max-w-full">
              <div className="aspect-square overflow-hidden rounded-3xl bg-gradient-to-br from-primary/20 to-pond/30 p-6 shadow-xl">
                <div className="flex h-full flex-col items-center justify-center gap-4 rounded-2xl bg-card/80 p-6 text-center backdrop-blur-sm">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-2xl bg-sand p-4">
                      <img
                        src={yuXiaoQing.url}
                        alt="渔小青 IP 形象 — 水乡少年，守护河湖生态"
                        className="mx-auto aspect-square w-full rounded-xl object-cover"
                      />
                      <p className="mt-2 font-medium text-foreground">渔小青</p>
                      <p className="text-xs text-muted-foreground">水乡守护者</p>
                    </div>
                    <div className="rounded-2xl bg-silk p-4">
                      <img
                        src={sangXiaoCan.url}
                        alt="桑小蚕 IP 形象 — 养蚕少女，传承桑蚕非遗"
                        className="mx-auto aspect-square w-full rounded-xl object-cover"
                      />
                      <p className="mt-2 font-medium text-foreground">桑小蚕</p>
                      <p className="text-xs text-muted-foreground">桑田守护者</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">桑蚕育乡土，青鱼守水乡</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 py-16 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground">六大学习模块</h2>
            <p className="mt-2 text-muted-foreground">从科普到互动，多维度感受渔桑文化</p>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
            {features.map((f) => (
              <Link key={f.title} to={f.to} search={"search" in f ? f.search : {}}>
                <Card className="h-full transition-shadow hover:shadow-md">
                  <CardContent className="flex items-start gap-3 p-4 sm:flex-col sm:items-stretch sm:gap-4 sm:p-6">
                    <div className={`shrink-0 inline-flex h-12 w-12 items-center justify-center overflow-hidden rounded-xl ${f.bg} sm:mb-0 sm:h-16 sm:w-16 sm:rounded-2xl`}>
                      <img
                        src={f.img}
                        alt={`${f.title}模块图标`}
                        className="h-full w-full object-contain p-1.5 sm:p-2"
                        loading="lazy"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-base font-semibold leading-tight text-foreground sm:text-xl">{f.title}</h3>
                      <p className="mt-1 text-sm text-muted-foreground sm:mt-2 sm:text-base">{f.desc}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary px-4 py-16 text-primary-foreground lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight">准备好开启渔桑之旅了吗？</h2>
          <p className="mt-3 text-primary-foreground/80">
            现在就进入渔桑小游戏，或者向 AI 助手提出你的第一个问题。
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" variant="secondary" className="rounded-full">
              <Link to="/pond">进入渔桑小游戏</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
            >
              <Link to="/ai-assistant">问 AI 助手</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="rounded-full border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
              onClick={() => window.dispatchEvent(new Event("yusangji:open-tour"))}
            >
              重看新手引导
            </Button>
          </div>

        </div>
      </section>
    </div>
  );
}
