import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { listFishSpecies, listCultureArticles, listQuizQuestions } from "@/lib/data.functions";
import { getMyRoles, claimFirstAdmin } from "@/lib/user.functions";
import {
  upsertFish,
  deleteFish,
  upsertArticle,
  deleteArticle,
  upsertQuiz,
  deleteQuiz,
} from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Plus, Trash2, Edit, Shield, Fish, BookOpen, HelpCircle } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type FishRow = Database["public"]["Tables"]["fish_species"]["Row"];
type ArticleRow = Database["public"]["Tables"]["culture_articles"]["Row"];
type QuizRow = Database["public"]["Tables"]["quiz_questions"]["Row"];

const adminQueryOptions = queryOptions({
  queryKey: ["admin-data"],
  queryFn: async () => {
    const [roles, fish, articles, quiz] = await Promise.all([
      getMyRoles(),
      listFishSpecies(),
      listCultureArticles(),
      listQuizQuestions(),
    ]);
    return { roles, fish, articles, quiz };
  },
});

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "内容管理 — 渔桑记" },
      { name: "description", content: "渔桑记后台管理，管理鱼类图鉴、文化科普和闯关题目。" },
      { property: "og:title", content: "内容管理 — 渔桑记" },
      { property: "og:description", content: "渔桑记后台管理，管理鱼类图鉴、文化科普和闯关题目。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(adminQueryOptions),
  component: AdminPage,
});

function AdminPage() {
  const { data, refetch } = useSuspenseQuery(adminQueryOptions);
  const [claiming, setClaiming] = useState(false);
  const claimAdmin = useServerFn(claimFirstAdmin);

  const isAdmin = data.roles.includes("admin");
  const isEditor = data.roles.includes("editor") || isAdmin;

  const handleClaim = async () => {
    setClaiming(true);
    try {
      await claimAdmin();
      toast.success("已成为首位管理员");
      await refetch();
    } catch (e) {
      toast.error("认领失败");
    } finally {
      setClaiming(false);
    }
  };

  if (!isEditor) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <Shield className="mx-auto h-16 w-16 text-muted-foreground/50" />
        <h1 className="mt-6 text-2xl font-bold">需要管理权限</h1>
        <p className="mt-2 text-muted-foreground">当前账号没有编辑或管理员权限。</p>
        <Button onClick={handleClaim} disabled={claiming} className="mt-6 rounded-full">
          认领首位管理员
        </Button>
        <div className="mt-4">
          <Button asChild variant="ghost">
            <Link to="/">返回首页</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">内容管理后台</h1>
          <p className="mt-2 text-muted-foreground">管理鱼类图鉴、文化科普文章和知识闯关题目</p>
        </div>
        <div className="text-sm text-muted-foreground">权限：{isAdmin ? "管理员" : "编辑"}</div>
      </div>

      <Tabs defaultValue="fish">
        <TabsList className="mb-6 grid w-full grid-cols-3 sm:w-auto">
          <TabsTrigger value="fish" className="gap-2">
            <Fish className="h-4 w-4" /> 鱼类图鉴
          </TabsTrigger>
          <TabsTrigger value="articles" className="gap-2">
            <BookOpen className="h-4 w-4" /> 文化科普
          </TabsTrigger>
          <TabsTrigger value="quiz" className="gap-2">
            <HelpCircle className="h-4 w-4" /> 闯关题目
          </TabsTrigger>
        </TabsList>

        <TabsContent value="fish">
          <FishManager fish={data.fish} onChange={refetch} />
        </TabsContent>
        <TabsContent value="articles">
          <ArticleManager articles={data.articles} onChange={refetch} />
        </TabsContent>
        <TabsContent value="quiz">
          <QuizManager quiz={data.quiz} fish={data.fish} onChange={refetch} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function FishManager({ fish, onChange }: { fish: FishRow[]; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Partial<FishRow> | null>(null);
  const upsert = useServerFn(upsertFish);
  const remove = useServerFn(deleteFish);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const data = {
      id: editing?.id || undefined,
      name: fd.get("name") as string,
      scientific_name: fd.get("scientific_name") as string,
      aliases: (fd.get("aliases") as string).split(",").map((s) => s.trim()).filter(Boolean),
      description: fd.get("description") as string,
      habitat: fd.get("habitat") as string,
      diet: fd.get("diet") as string,
      fun_facts: (fd.get("fun_facts") as string).split("\n").map((s) => s.trim()).filter(Boolean),
      image_url: fd.get("image_url") as string,
      category: fd.get("category") as string,
      difficulty: fd.get("difficulty") as string,
    };
    try {
      await upsert({ data });
      toast.success(editing?.id ? "已更新" : "已添加");
      setOpen(false);
      setEditing(null);
      form.reset();
      onChange();
    } catch (err) {
      toast.error("保存失败");
    }
  };

  const startEdit = (item: FishRow) => {
    setEditing(item);
    setOpen(true);
  };

  const startCreate = () => {
    setEditing({});
    setOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("确定删除这条鱼类记录？")) return;
    try {
      await remove({ data: { id } });
      toast.success("已删除");
      onChange();
    } catch (err) {
      toast.error("删除失败");
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">鱼类图鉴列表</h2>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={startCreate} className="rounded-full">
                <Plus className="mr-2 h-4 w-4" /> 新增鱼类
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editing?.id ? "编辑鱼类" : "新增鱼类"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>名称</Label>
                    <Input name="name" defaultValue={editing?.name || ""} required />
                  </div>
                  <div className="space-y-2">
                    <Label>学名</Label>
                    <Input name="scientific_name" defaultValue={editing?.scientific_name || ""} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>别名（逗号分隔）</Label>
                  <Input name="aliases" defaultValue={editing?.aliases?.join(", ") || ""} />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>栖息地</Label>
                    <Input name="habitat" defaultValue={editing?.habitat || ""} />
                  </div>
                  <div className="space-y-2">
                    <Label>食性</Label>
                    <Input name="diet" defaultValue={editing?.diet || ""} />
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>分类</Label>
                    <Input name="category" defaultValue={editing?.category || ""} />
                  </div>
                  <div className="space-y-2">
                    <Label>难度</Label>
                    <Input name="difficulty" defaultValue={editing?.difficulty || ""} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>图片 URL</Label>
                  <Input name="image_url" defaultValue={editing?.image_url || ""} />
                </div>
                <div className="space-y-2">
                  <Label>描述</Label>
                  <Textarea name="description" defaultValue={editing?.description || ""} rows={3} />
                </div>
                <div className="space-y-2">
                  <Label>趣味知识（每行一条）</Label>
                  <Textarea name="fun_facts" defaultValue={editing?.fun_facts?.join("\n") || ""} rows={3} />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit">保存</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
        <div className="divide-y divide-border">
          {fish.map((item) => (
            <div key={item.id} className="flex items-center justify-between py-4">
              <div>
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-muted-foreground">{item.category}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" onClick={() => startEdit(item)}>
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function ArticleManager({ articles, onChange }: { articles: ArticleRow[]; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Partial<ArticleRow> | null>(null);
  const upsert = useServerFn(upsertArticle);
  const remove = useServerFn(deleteArticle);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const data = {
      id: editing?.id || undefined,
      title: fd.get("title") as string,
      slug: fd.get("slug") as string,
      summary: fd.get("summary") as string,
      content: fd.get("content") as string,
      cover_url: fd.get("cover_url") as string,
      category: fd.get("category") as string,
      order_index: Number(fd.get("order_index") || 0),
    };
    try {
      await upsert({ data });
      toast.success(editing?.id ? "已更新" : "已添加");
      setOpen(false);
      setEditing(null);
      form.reset();
      onChange();
    } catch (err) {
      toast.error("保存失败");
    }
  };

  const startEdit = (item: ArticleRow) => {
    setEditing(item);
    setOpen(true);
  };

  const startCreate = () => {
    setEditing({});
    setOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("确定删除这篇文章？")) return;
    try {
      await remove({ data: { id } });
      toast.success("已删除");
      onChange();
    } catch (err) {
      toast.error("删除失败");
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">文化科普文章</h2>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={startCreate} className="rounded-full">
                <Plus className="mr-2 h-4 w-4" /> 新增文章
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editing?.id ? "编辑文章" : "新增文章"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>标题</Label>
                    <Input name="title" defaultValue={editing?.title || ""} required />
                  </div>
                  <div className="space-y-2">
                    <Label>Slug</Label>
                    <Input name="slug" defaultValue={editing?.slug || ""} required />
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>分类</Label>
                    <Input name="category" defaultValue={editing?.category || ""} />
                  </div>
                  <div className="space-y-2">
                    <Label>排序</Label>
                    <Input name="order_index" type="number" defaultValue={editing?.order_index || 0} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>封面 URL</Label>
                  <Input name="cover_url" defaultValue={editing?.cover_url || ""} />
                </div>
                <div className="space-y-2">
                  <Label>摘要</Label>
                  <Textarea name="summary" defaultValue={editing?.summary || ""} rows={2} />
                </div>
                <div className="space-y-2">
                  <Label>正文（支持 Markdown）</Label>
                  <Textarea name="content" defaultValue={editing?.content || ""} rows={8} />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit">保存</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
        <div className="divide-y divide-border">
          {articles.map((item) => (
            <div key={item.id} className="flex items-center justify-between py-4">
              <div>
                <p className="font-medium">{item.title}</p>
                <p className="text-sm text-muted-foreground">/{item.slug}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" onClick={() => startEdit(item)}>
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function QuizManager({ quiz, fish, onChange }: { quiz: QuizRow[]; fish: FishRow[]; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Partial<QuizRow> | null>(null);
  const upsert = useServerFn(upsertQuiz);
  const remove = useServerFn(deleteQuiz);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const options = (fd.get("options") as string).split("\n").map((s) => s.trim()).filter(Boolean);
    const data = {
      id: editing?.id || undefined,
      question: fd.get("question") as string,
      options,
      correct_index: Number(fd.get("correct_index") || 0),
      explanation: fd.get("explanation") as string,
      related_fish_id: (fd.get("related_fish_id") as string) || undefined,
      difficulty: fd.get("difficulty") as string,
      category: fd.get("category") as string,
    };
    try {
      await upsert({ data });
      toast.success(editing?.id ? "已更新" : "已添加");
      setOpen(false);
      setEditing(null);
      form.reset();
      onChange();
    } catch (err) {
      toast.error("保存失败");
    }
  };

  const startEdit = (item: QuizRow) => {
    setEditing(item);
    setOpen(true);
  };

  const startCreate = () => {
    setEditing({});
    setOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("确定删除这道题目？")) return;
    try {
      await remove({ data: { id } });
      toast.success("已删除");
      onChange();
    } catch (err) {
      toast.error("删除失败");
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">闯关题目列表</h2>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={startCreate} className="rounded-full">
                <Plus className="mr-2 h-4 w-4" /> 新增题目
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editing?.id ? "编辑题目" : "新增题目"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>题目</Label>
                  <Textarea name="question" defaultValue={editing?.question || ""} required />
                </div>
                <div className="space-y-2">
                  <Label>选项（每行一个，第一个为 0 号）</Label>
                  <Textarea name="options" defaultValue={editing?.options?.join("\n") || ""} rows={4} required />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>正确答案序号</Label>
                    <Input name="correct_index" type="number" min={0} defaultValue={editing?.correct_index || 0} required />
                  </div>
                  <div className="space-y-2">
                    <Label>难度</Label>
                    <Input name="difficulty" defaultValue={editing?.difficulty || ""} />
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>关联鱼类</Label>
                    <select
                      name="related_fish_id"
                      defaultValue={editing?.related_fish_id || ""}
                      className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="">无</option>
                      {fish.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>分类</Label>
                    <Input name="category" defaultValue={editing?.category || ""} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>解析</Label>
                  <Textarea name="explanation" defaultValue={editing?.explanation || ""} rows={3} />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit">保存</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
        <div className="divide-y divide-border">
          {quiz.map((item) => (
            <div key={item.id} className="flex items-center justify-between py-4">
              <div className="max-w-xl">
                <p className="line-clamp-2 font-medium">{item.question}</p>
                <p className="text-sm text-muted-foreground">答案：{item.options[item.correct_index]}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" onClick={() => startEdit(item)}>
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
