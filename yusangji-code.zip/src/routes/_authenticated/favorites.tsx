import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { listMyFavorites } from "@/lib/user.functions";
import { listFishSpecies, listCultureArticles } from "@/lib/data.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Fish, BookOpen } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type FavoriteRow = Database["public"]["Tables"]["user_favorites"]["Row"];
type FishRow = Database["public"]["Tables"]["fish_species"]["Row"];
type ArticleRow = Database["public"]["Tables"]["culture_articles"]["Row"];

type EnrichedFavorite =
  | (FavoriteRow & { kind: "fish"; item: FishRow })
  | (FavoriteRow & { kind: "article"; item: ArticleRow });

const favoritesQueryOptions = queryOptions({
  queryKey: ["my-favorites"],
  queryFn: async () => {
    const [favorites, fish, articles] = await Promise.all([
      listMyFavorites(),
      listFishSpecies(),
      listCultureArticles(),
    ]);
    const fishMap = new Map<string, FishRow>(fish.map((f) => [f.id, f]));
    const articleMap = new Map<string, ArticleRow>(articles.map((a) => [a.id, a]));
    const enriched: EnrichedFavorite[] = (favorites as FavoriteRow[]).map((f) => {
      if (f.target_type === "fish") {
        const item = fishMap.get(f.target_id)!;
        return { ...f, kind: "fish" as const, item };
      }
      const item = articleMap.get(f.target_id)!;
      return { ...f, kind: "article" as const, item };
    });
    return enriched.filter((f) => !!f.item);
  },
});

export const Route = createFileRoute("/_authenticated/favorites")({
  head: () => ({
    meta: [
      { title: "我的收藏 — 渔桑记" },
      { name: "description", content: "查看你收藏的鱼类图鉴和文化科普文章。" },
      { property: "og:title", content: "我的收藏 — 渔桑记" },
      { property: "og:description", content: "查看你收藏的鱼类图鉴和文化科普文章。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(favoritesQueryOptions),
  component: FavoritesPage,
});

function FavoritesPage() {
  const { data: favorites } = useSuspenseQuery(favoritesQueryOptions);

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="flex items-center gap-2 text-3xl font-bold text-foreground">
          <Heart className="h-7 w-7 text-destructive" />
          我的收藏
        </h1>
        <p className="mt-2 text-muted-foreground">随时回顾你感兴趣的鱼类和文化知识</p>
      </div>

      {favorites.length === 0 ? (
        <Card className="py-12 text-center">
          <CardContent>
            <Heart className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <p className="mt-4 text-muted-foreground">还没有收藏任何内容</p>
            <div className="mt-6 flex justify-center gap-3">
              <Button asChild variant="outline" className="rounded-full">
                <Link to="/fish">去图鉴看看</Link>
              </Button>
              <Button asChild className="rounded-full">
                <Link to="/culture">读文化科普</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {favorites.map((f) => {
            const isFish = f.kind === "fish";
            const link = isFish ? `/fish/${f.item.id}` : `/culture/${(f.item as ArticleRow).slug}`;
            return (
              <Link key={f.id} to={link} className="group">
                <Card className="h-full transition-shadow hover:shadow-md">
                  <CardHeader className="pb-2">
                    <div className="mb-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
                      {isFish ? <Fish className="h-4 w-4 text-leaf" /> : <BookOpen className="h-4 w-4 text-qing" />}
                      {isFish ? "鱼类图鉴" : "文化科普"}
                    </div>
                    <CardTitle className="text-lg group-hover:text-primary">
                      {isFish ? f.item.name : f.item.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="line-clamp-2 text-sm text-muted-foreground">
                      {isFish ? f.item.fun_facts?.[0] || f.item.description || "" : f.item.summary || ""}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
