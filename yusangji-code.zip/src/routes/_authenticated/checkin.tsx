import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { listMyCheckIns, checkInToday } from "@/lib/user.functions";
import { CheckInCalendar } from "@/components/CheckInCalendar";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";

const checkInsQueryOptions = queryOptions({
  queryKey: ["my-check-ins"],
  queryFn: () => listMyCheckIns(),
});

export const Route = createFileRoute("/_authenticated/checkin")({
  head: () => ({
    meta: [
      { title: "学习打卡 — 渔桑记" },
      { name: "description", content: "记录每日学习足迹，养成探索渔桑文化的好习惯。" },
      { property: "og:title", content: "学习打卡 — 渔桑记" },
      { property: "og:description", content: "记录每日学习足迹，养成探索渔桑文化的好习惯。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(checkInsQueryOptions),
  component: CheckInPage,
});

function CheckInPage() {
  const { data: checkIns, refetch } = useSuspenseQuery(checkInsQueryOptions);
  const [loading, setLoading] = useState(false);
  const doCheckIn = useServerFn(checkInToday);

  const handleCheckIn = async () => {
    setLoading(true);
    try {
      await doCheckIn({ data: {} });
      toast.success("打卡成功！");
      await refetch();
    } catch (e) {
      toast.error("打卡失败，请重试");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <CheckInCalendar checkIns={checkIns} onCheckIn={handleCheckIn} loading={loading} />
    </div>
  );
}
