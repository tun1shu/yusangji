import { createFileRoute } from "@tanstack/react-router";
import { AiChat } from "@/components/AiChat";
import { MessageCircle } from "lucide-react";

export const Route = createFileRoute("/ai-assistant")({
  head: () => ({
    meta: [
      { title: "AI 科普助手 — 渔桑记" },
      { name: "description", content: "向渔桑记 AI 助手提问，获取渔桑文化、鱼类知识科普解答。" },
      { property: "og:title", content: "AI 科普助手 — 渔桑记" },
      { property: "og:description", content: "向渔桑记 AI 助手提问，获取渔桑文化、鱼类知识科普解答。" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AiAssistantPage,
});

function AiAssistantPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-500/10">
          <MessageCircle className="h-6 w-6 text-purple-500" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">AI 科普助手</h1>
        <p className="mt-2 text-muted-foreground">有问题随时问，渔桑 AI 陪你一起学</p>
      </div>
      <AiChat />
    </div>
  );
}
