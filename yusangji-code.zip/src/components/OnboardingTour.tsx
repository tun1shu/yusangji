import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { BookOpen, Heart, Trophy, X, ArrowRight, ArrowLeft, Sparkles } from "lucide-react";
import yuXiaoQing from "@/assets/yuxiaoqing.jpg.asset.json";
import sangXiaoCan from "@/assets/sangxiaocan.png.asset.json";

const STORAGE_KEY = "yusangji-onboarding-done";

type Step = {
  guide: "yu" | "sang";
  icon: typeof BookOpen;
  tag: string;
  title: string;
  desc: string;
  bubble: string;
  bg: string;
  color: string;
};

const steps: Step[] = [
  {
    guide: "yu",
    icon: BookOpen,
    tag: "第一步 · 学习",
    title: "先去看看水里的朋友",
    desc: "在「鱼类图鉴」认识草鱼、鲫鱼、鲤鱼，在「桑基鱼塘」读懂千年生态循环智慧。",
    bubble: "我是渔小青，跟我下水认认鱼！",
    bg: "bg-pond/10",
    color: "text-pond",
  },
  {
    guide: "sang",
    icon: Heart,
    tag: "第二步 · 收藏",
    title: "喜欢的知识收进小篮子",
    desc: "点一下卡片上的爱心，鱼类和文章就会存进「我的收藏」，随时回来复习。",
    bubble: "我是桑小蚕，好知识要装进篮子里～",
    bg: "bg-leaf/10",
    color: "text-leaf",
  },
  {
    guide: "yu",
    icon: Trophy,
    tag: "第三步 · 闯关",
    title: "答题闯关检验成果",
    desc: "在「知识闯关」挑战趣味题目，每题都有解析；坚持每日打卡还能累积连续天数。",
    bubble: "学完来闯关，看看能拿几分！",
    bg: "bg-primary/10",
    color: "text-primary",
  },
];

export function OnboardingTour() {
  const [open, setOpen] = useState(false);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    try {
      if (!localStorage.getItem(STORAGE_KEY)) setOpen(true);
    } catch {
      /* storage unavailable */
    }
    const handler = () => {
      setIndex(0);
      setOpen(true);
    };
    window.addEventListener("yusangji:open-tour", handler);
    return () => window.removeEventListener("yusangji:open-tour", handler);
  }, []);

  const close = () => {
    setOpen(false);
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch {
      /* ignore */
    }
  };

  if (!open) return null;

  const step = steps[index]!;
  const isLast = index === steps.length - 1;
  const avatar = step.guide === "yu" ? yuXiaoQing.url : sangXiaoCan.url;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="新手引导"
    >
      <div className="animate-scale-in relative w-full max-w-lg overflow-hidden rounded-3xl border border-border bg-card shadow-xl">
        <button
          onClick={close}
          aria-label="跳过引导"
          className="absolute right-3 top-3 rounded-full p-2 text-muted-foreground transition-colors hover:bg-muted"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="bg-gradient-to-br from-sand via-card to-pond/20 px-6 pb-6 pt-8">
          <div className="flex items-start gap-4">
            <img
              key={avatar}
              src={avatar}
              alt={step.guide === "yu" ? "渔小青" : "桑小蚕"}
              className="animate-fade-in h-24 w-24 flex-shrink-0 rounded-2xl bg-card object-cover shadow-sm"
            />
            <div className="animate-fade-in relative mt-3 rounded-2xl rounded-bl-sm bg-card px-4 py-3 text-sm text-foreground shadow-sm">
              {step.bubble}
            </div>
          </div>
        </div>

        <div className="space-y-4 p-6">
          <div className="flex items-center gap-2">
            <span
              className={`inline-flex h-9 w-9 items-center justify-center rounded-xl ${step.bg}`}
            >
              <step.icon className={`h-5 w-5 ${step.color}`} />
            </span>
            <span className="text-xs font-medium tracking-wide text-muted-foreground">
              {step.tag}
            </span>
          </div>
          <div key={index} className="animate-fade-in space-y-2">
            <h2 className="text-xl font-bold text-foreground">{step.title}</h2>
            <p className="text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
          </div>

          <div className="flex items-center gap-2 pt-1">
            {steps.map((s, i) => (
              <span
                key={s.tag}
                className={`h-1.5 rounded-full transition-all ${
                  i === index ? "w-6 bg-primary" : "w-1.5 bg-border"
                }`}
              />
            ))}
          </div>

          <div className="flex items-center justify-between gap-2 pt-2">
            <Button variant="ghost" size="sm" className="rounded-full" onClick={close}>
              跳过
            </Button>
            <div className="flex gap-2">
              {index > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full"
                  onClick={() => setIndex((i) => i - 1)}
                >
                  <ArrowLeft className="mr-1 h-4 w-4" /> 上一步
                </Button>
              )}
              {isLast ? (
                <Button asChild size="sm" className="rounded-full" onClick={close}>
                  <Link to="/fish">
                    <Sparkles className="mr-1 h-4 w-4" /> 开始学习
                  </Link>
                </Button>
              ) : (
                <Button size="sm" className="rounded-full" onClick={() => setIndex((i) => i + 1)}>
                  下一步 <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
