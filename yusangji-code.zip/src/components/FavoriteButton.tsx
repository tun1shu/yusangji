import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { Heart, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { addFavorite, removeFavorite, listMyFavorites } from "@/lib/user.functions";

type Props = {
  targetId: string;
  targetType: "fish" | "article";
  className?: string;
};

type FavoriteRow = { target_id: string; target_type: string };

export function useMyFavorites() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["favorites", "raw"],
    queryFn: () => listMyFavorites(),
    enabled: !!user,
    staleTime: 30_000,
  });
}

export function FavoriteButton({ targetId, targetType, className }: Props) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: favorites } = useMyFavorites();

  const isFavorited = ((favorites as FavoriteRow[] | undefined) ?? []).some(
    (f) => f.target_id === targetId && f.target_type === targetType,
  );

  const mutation = useMutation({
    mutationFn: async () => {
      const payload = { target_id: targetId, target_type: targetType };
      if (isFavorited) return removeFavorite({ data: payload });
      return addFavorite({ data: payload });
    },
    onSuccess: () => {
      toast.success(isFavorited ? "已取消收藏" : "已加入收藏夹");
      queryClient.invalidateQueries({ queryKey: ["favorites", "raw"] });
      queryClient.invalidateQueries({ queryKey: ["my-favorites"] });
    },
    onError: () => toast.error("操作失败，请稍后再试"),
  });

  const handleClick = () => {
    if (!user) {
      toast.info("登录后即可收藏这条知识");
      navigate({ to: "/auth" });
      return;
    }
    mutation.mutate();
  };

  return (
    <Button
      type="button"
      variant={isFavorited ? "secondary" : "outline"}
      className={className ?? "flex-1 rounded-full"}
      disabled={mutation.isPending}
      aria-pressed={isFavorited}
      onClick={handleClick}
    >
      {mutation.isPending ? (
        <Loader2 className="mr-1 h-4 w-4 animate-spin" />
      ) : (
        <Heart className={`mr-1 h-4 w-4 ${isFavorited ? "fill-destructive text-destructive" : ""}`} />
      )}
      {isFavorited ? "已收藏" : "收藏"}
    </Button>
  );
}
