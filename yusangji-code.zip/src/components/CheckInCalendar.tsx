import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameDay,
  isToday,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
} from "date-fns";
import { zhCN } from "date-fns/locale";
import { ChevronLeft, ChevronRight, CalendarCheck, Flame } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type CheckIn = Database["public"]["Tables"]["check_ins"]["Row"];

export function CheckInCalendar({
  checkIns,
  onCheckIn,
  loading,
}: {
  checkIns: CheckIn[];
  onCheckIn: () => void;
  loading: boolean;
}) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const today = new Date();
  const checkedDates = checkIns.map((c) => new Date(c.checked_in_at));
  const streak = computeStreak(checkedDates);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart, { locale: zhCN });
  const calendarEnd = endOfWeek(monthEnd, { locale: zhCN });
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  const weekDays = ["日", "一", "二", "三", "四", "五", "六"];

  const alreadyCheckedToday = checkedDates.some((d) => isSameDay(d, today));

  return (
    <Card>
      <CardHeader className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <CardTitle className="flex items-center gap-2 text-xl">
            <CalendarCheck className="h-5 w-5 text-primary" />
            学习打卡
          </CardTitle>
          <p className="mt-1 text-sm text-muted-foreground">每天学习一点点，记录成长足迹</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 rounded-full bg-orange-500/10 px-3 py-1 text-sm font-medium text-orange-600">
            <Flame className="h-4 w-4" />
            连续 {streak} 天
          </div>
          <Button onClick={onCheckIn} disabled={alreadyCheckedToday || loading} className="rounded-full">
            {alreadyCheckedToday ? "今日已打卡" : "今日打卡"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex items-center justify-between">
          <Button variant="ghost" size="icon" onClick={() => setCurrentMonth((m) => subMonths(m, 1))}>
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <span className="text-lg font-bold">
            {format(currentMonth, "yyyy 年 M 月", { locale: zhCN })}
          </span>
          <Button variant="ghost" size="icon" onClick={() => setCurrentMonth((m) => addMonths(m, 1))}>
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-sm font-medium text-muted-foreground">
          {weekDays.map((d) => (
            <div key={d} className="py-2">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {days.map((day) => {
            const checked = checkedDates.some((d) => isSameDay(d, day));
            const isCurrentMonth = day.getMonth() === currentMonth.getMonth();
            return (
              <div
                key={day.toISOString()}
                className={`flex aspect-square items-center justify-center rounded-xl text-sm font-medium ${
                  isToday(day)
                    ? "bg-primary text-primary-foreground"
                    : checked
                      ? "bg-leaf/20 text-leaf-foreground"
                      : isCurrentMonth
                        ? "bg-muted text-foreground"
                        : "text-muted-foreground/50"
                }`}
              >
                {format(day, "d")}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

function computeStreak(dates: Date[]) {
  if (dates.length === 0) return 0;
  const sorted = [...dates].sort((a, b) => b.getTime() - a.getTime());
  let streak = 0;
  let cursor = new Date();
  cursor.setHours(0, 0, 0, 0);
  // If not checked today, start from yesterday
  const checkedToday = sorted.some((d) => isSameDay(d, cursor));
  if (!checkedToday) {
    cursor.setDate(cursor.getDate() - 1);
  }
  while (true) {
    if (sorted.some((d) => isSameDay(d, cursor))) {
      streak++;
      cursor.setDate(cursor.getDate() - 1);
    } else {
      break;
    }
  }
  return streak;
}
