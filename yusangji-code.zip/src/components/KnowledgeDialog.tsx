import { useEffect, useRef, useState, type ReactNode } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ChevronUp, ChevronDown, CornerUpLeft } from "lucide-react";


type Props = {
  open: boolean;
  index: number;
  total: number;
  title: string;
  subtitle?: string | null;
  image: string;
  children: ReactNode;
  footer?: ReactNode;
  onIndexChange: (next: number) => void;
  onClose: () => void;
};

export function KnowledgeDialog({
  open,
  index,
  total,
  title,
  subtitle,
  image,
  children,
  footer,
  onIndexChange,
  onClose,
}: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const start = useRef<{ x: number; y: number; atTop: boolean; atBottom: boolean } | null>(null);
  const axis = useRef<"x" | "y" | "none" | null>(null);
  const [drag, setDrag] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);


  const hasPrev = index > 0;
  const hasNext = index < total - 1;

  const go = (delta: number) => {
    const next = index + delta;
    if (next < 0 || next > total - 1) return;
    onIndexChange(next);
  };

  // Reset scroll position when switching entries
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
  }, [index]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "PageDown") {
        e.preventDefault();
        go(1);
      } else if (e.key === "ArrowUp" || e.key === "PageUp") {
        e.preventDefault();
        go(-1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  // Reset drag when entry changes / dialog closes
  useEffect(() => {
    setDrag({ x: 0, y: 0 });
    setDragging(false);
  }, [index, open]);

  const resist = (v: number, allowed: boolean) => (allowed ? v : v * 0.18);

  const handleTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0];
    const el = scrollRef.current;
    if (!t || !el) return;
    start.current = {
      x: t.clientX,
      y: t.clientY,
      atTop: el.scrollTop <= 2,
      atBottom: el.scrollTop + el.clientHeight >= el.scrollHeight - 2,
    };
    axis.current = null;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const s = start.current;
    const t = e.touches[0];
    if (!s || !t) return;
    const dx = t.clientX - s.x;
    const dy = t.clientY - s.y;

    if (axis.current === null) {
      if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
      if (Math.abs(dx) > Math.abs(dy) * 1.2) {
        axis.current = "x";
      } else if ((dy < 0 && s.atBottom) || (dy > 0 && s.atTop)) {
        // only hijack vertical drag when content is already at its edge
        axis.current = "y";
      } else {
        axis.current = "none"; // let the content scroll normally
      }
      setDragging(axis.current !== "none");
    }

    if (axis.current === "none") return;

    if (axis.current === "x") {
      const allowed = dx < 0 ? hasNext : hasPrev;
      setDrag({ x: resist(dx, allowed), y: 0 });
    } else {
      const allowed = dy < 0 ? hasNext : hasPrev;
      setDrag({ x: 0, y: resist(dy, allowed) });
    }
  };

  const handleTouchEnd = () => {
    const currentAxis = axis.current;
    const { x, y } = drag;
    start.current = null;
    axis.current = null;
    setDragging(false);
    setDrag({ x: 0, y: 0 });
    if (currentAxis === "x" && Math.abs(x) > 60) {
      go(x < 0 ? 1 : -1);
    } else if (currentAxis === "y" && Math.abs(y) > 60) {
      go(y < 0 ? 1 : -1);
    }
  };


  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="flex max-h-[88vh] flex-col gap-0 overflow-hidden p-0 sm:max-w-2xl">
        <div className="flex items-center justify-between border-b border-border bg-card px-6 py-3">
          <span className="rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
            第 {index + 1} / {total} 条
          </span>
          <div className="flex items-center gap-1 pr-8">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full"
              disabled={!hasPrev}
              aria-label="上一条"
              onClick={() => go(-1)}
            >
              <ChevronUp className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full"
              disabled={!hasNext}
              aria-label="下一条"
              onClick={() => go(1)}
            >
              <ChevronDown className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="h-1 w-full bg-muted">
          <div
            className="h-full bg-pond transition-all duration-300"
            style={{ width: `${((index + 1) / Math.max(total, 1)) * 100}%` }}
          />
        </div>

        <div
          ref={scrollRef}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onTouchCancel={handleTouchEnd}
          className="flex-1 overflow-y-auto overscroll-contain px-6 py-5"
          style={{ touchAction: "pan-y" }}
        >
          <div
            className="space-y-4"
            style={{
              transform: `translate3d(${drag.x}px, ${drag.y}px, 0)`,
              opacity: dragging ? 1 - Math.min(Math.hypot(drag.x, drag.y) / 320, 0.35) : 1,
              transition: dragging ? "none" : "transform 260ms cubic-bezier(0.22,1,0.36,1), opacity 200ms ease",
              willChange: "transform",
            }}
          >
            <DialogHeader className="text-left">
              <DialogTitle className="text-2xl">{title}</DialogTitle>
              {subtitle ? <DialogDescription>{subtitle}</DialogDescription> : null}
            </DialogHeader>

            <div className="overflow-hidden rounded-xl bg-muted">
              <img src={image} alt={title} className="h-56 w-full object-cover" draggable={false} />
            </div>

            {children}

            <p className="pt-2 text-center text-xs text-muted-foreground">
              左右拖拽或滑到顶部/底部再上下拖拽可切换条目，也可使用 ↑ ↓ 键
            </p>
          </div>
        </div>


        <div className="flex flex-col gap-2 border-t border-border bg-card px-6 py-3 sm:flex-row">
          <Button
            type="button"
            variant="outline"
            className="flex-1 rounded-full"
            onClick={onClose}
          >
            <CornerUpLeft className="mr-1 h-4 w-4" />
            返回卡片位置
          </Button>
          {footer}
        </div>
      </DialogContent>
    </Dialog>
  );
}
