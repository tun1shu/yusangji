import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type Props = {
  query: string;
  onQueryChange: (v: string) => void;
  categories: string[];
  activeCategory: string;
  onCategoryChange: (v: string) => void;
  placeholder?: string;
  resultCount: number;
};

export function FilterBar({
  query,
  onQueryChange,
  categories,
  activeCategory,
  onCategoryChange,
  placeholder = "搜索关键词…",
  resultCount,
}: Props) {
  const all = ["全部", ...categories];

  return (
    <div className="mb-8 space-y-3">
      <div className="relative mx-auto max-w-xl">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder={placeholder}
          aria-label="搜索"
          className="rounded-full pl-9 pr-9"
        />
        {query && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="清空搜索"
            onClick={() => onQueryChange("")}
            className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {all.length > 1 && (
        <div className="flex flex-wrap items-center justify-center gap-2">
          {all.map((c) => (
            <button key={c} type="button" onClick={() => onCategoryChange(c)}>
              <Badge
                variant={activeCategory === c ? "default" : "outline"}
                className="cursor-pointer rounded-full px-3 py-1 text-xs"
              >
                {c}
              </Badge>
            </button>
          ))}
        </div>
      )}

      <p className="text-center text-xs text-muted-foreground">共 {resultCount} 条结果</p>
    </div>
  );
}
