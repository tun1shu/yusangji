import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Database } from "@/integrations/supabase/types";

export type Fish = Database["public"]["Tables"]["fish_species"]["Row"];

const difficultyMap: Record<string, string> = {
  easy: "简单",
  medium: "中等",
  hard: "挑战",
};

export function fishImage(fish: Fish) {
  return fish.image_url || "https://placehold.co/600x400/e2e8f0/64748b?text=暂无图片";
}

export function FishDetail({ fish }: { fish: Fish }) {
  return (
    <div className="space-y-4 text-sm leading-relaxed">
      {fish.aliases && fish.aliases.length > 0 && (
        <p className="text-muted-foreground">别名：{fish.aliases.join("、")}</p>
      )}
      {fish.description && (
        <section>
          <h4 className="mb-1 font-semibold text-foreground">简介</h4>
          <p className="whitespace-pre-line text-muted-foreground">{fish.description}</p>
        </section>
      )}
      {fish.habitat && (
        <section>
          <h4 className="mb-1 font-semibold text-foreground">栖息环境</h4>
          <p className="whitespace-pre-line text-muted-foreground">{fish.habitat}</p>
        </section>
      )}
      {fish.diet && (
        <section>
          <h4 className="mb-1 font-semibold text-foreground">食性</h4>
          <p className="whitespace-pre-line text-muted-foreground">{fish.diet}</p>
        </section>
      )}
      {fish.fun_facts && fish.fun_facts.length > 0 && (
        <section>
          <h4 className="mb-1 font-semibold text-foreground">趣味知识</h4>
          <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
            {fish.fun_facts.map((fact, i) => (
              <li key={i}>{fact}</li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

export function FishCard({ fish, onOpen }: { fish: Fish; onOpen?: () => void }) {
  const image = fishImage(fish);

  return (
    <Card className="group h-full overflow-hidden transition-shadow hover:shadow-md">
      <button
        type="button"
        onClick={onOpen}
        aria-label={`查看${fish.name}的知识介绍`}
        className="block w-full cursor-pointer"
      >
        <div className="aspect-video overflow-hidden bg-muted">
          <img
            src={image}
            alt={fish.name}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
      </button>
      <CardContent className="p-4">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-lg font-bold text-foreground">{fish.name}</h3>
          {fish.difficulty && (
            <Badge variant="secondary" className="text-xs">
              {difficultyMap[fish.difficulty] || fish.difficulty}
            </Badge>
          )}
        </div>
        {fish.scientific_name && (
          <p className="mb-2 text-xs italic text-muted-foreground">{fish.scientific_name}</p>
        )}
        {fish.aliases && fish.aliases.length > 0 && (
          <p className="mb-2 text-sm text-muted-foreground">别名：{fish.aliases.join("、")}</p>
        )}
        <div className="flex items-center justify-between">
          {fish.category ? (
            <Badge variant="outline" className="text-xs">
              {fish.category}
            </Badge>
          ) : (
            <span />
          )}
          <button
            type="button"
            onClick={onOpen}
            className="text-xs font-medium text-pond hover:underline"
          >
            点击图片看知识
          </button>
        </div>
      </CardContent>
    </Card>
  );
}
