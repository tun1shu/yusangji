import { Link } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, User, LogOut, Shield } from "lucide-react";
import logoAsset from "@/assets/logo-yusang.png.asset.json";

import { useState } from "react";
import { A11ySettingsButton } from "@/components/A11ySettings";

const navItems = [
  { to: "/fish", label: "鱼类图鉴" },
  { to: "/culture", label: "桑基鱼塘" },
  { to: "/quiz", label: "知识闯关" },
  { to: "/pond", label: "渔桑小游戏" },
  { to: "/ai-assistant", label: "AI 助手" },
];

export function Header() {
  const { user, loading, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isAdmin =
    (user?.app_metadata?.["roles"] as string[] | undefined)?.includes("admin") ||
    user?.app_metadata?.["role"] === "admin";

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2 text-primary">
          <img src={logoAsset.url} alt="渔桑记标志" className="h-9 w-9 object-contain" />
          <span className="hidden text-xl font-bold tracking-tight sm:inline">渔桑记</span>
        </Link>


        <nav className="hidden items-center gap-1 md:flex">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeProps={{ className: "text-primary bg-primary/10" }}
              className="rounded-full px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1 sm:gap-2">
          <A11ySettingsButton />
          {loading ? (
            <div className="h-8 w-8 animate-pulse rounded-full bg-muted" />
          ) : user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="我的账户" className="min-h-11 min-w-11 rounded-full">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem asChild>
                  <Link to="/checkin" className="cursor-pointer">
                    学习打卡
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/favorites" className="cursor-pointer">
                    我的收藏
                  </Link>
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem asChild>
                    <Link to="/admin" className="cursor-pointer">
                      <Shield className="mr-2 h-4 w-4" />
                      后台管理
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={signOut} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  退出登录
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild variant="default" size="sm" className="rounded-full">
              <Link to="/auth">登录</Link>
            </Button>
          )}

          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="打开菜单" className="min-h-11 min-w-11 md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64">
              <nav className="mt-8 flex flex-col gap-2">
                {navItems.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileOpen(false)}
                    className="flex min-h-11 items-center rounded-lg px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
                  >
                    {item.label}
                  </Link>
                ))}
                <hr className="my-2 border-border" />
                {user ? (
                  <>
                    <Link
                      to="/checkin"
                      onClick={() => setMobileOpen(false)}
                      className="flex min-h-11 items-center rounded-lg px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
                    >
                      学习打卡
                    </Link>
                    <Link
                      to="/favorites"
                      onClick={() => setMobileOpen(false)}
                      className="flex min-h-11 items-center rounded-lg px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
                    >
                      我的收藏
                    </Link>
                    {isAdmin && (
                      <Link
                        to="/admin"
                        onClick={() => setMobileOpen(false)}
                        className="flex min-h-11 items-center rounded-lg px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
                      >
                        后台管理
                      </Link>
                    )}
                    <button
                      onClick={() => {
                        signOut();
                        setMobileOpen(false);
                      }}
                      className="flex min-h-11 items-center rounded-lg px-3 py-2 text-left text-base font-medium text-destructive hover:bg-accent"
                    >
                      退出登录
                    </button>
                  </>
                ) : (
                  <Link
                    to="/auth"
                    onClick={() => setMobileOpen(false)}
                    className="flex min-h-11 items-center rounded-lg px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
                  >
                    登录 / 注册
                  </Link>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
