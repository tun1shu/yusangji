import { Link } from "@tanstack/react-router";
import { Fish, Leaf, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <div className="flex items-center gap-2 text-primary">
            <Fish className="h-6 w-6" />
            <span className="text-lg font-bold tracking-tight">渔桑记</span>
            <Leaf className="h-5 w-5 text-leaf" />
          </div>
          <nav className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <Link to="/" className="hover:text-foreground">
              首页
            </Link>
            <Link to="/fish" className="hover:text-foreground">
              鱼类图鉴
            </Link>
            <Link to="/culture" className="hover:text-foreground">
              桑基鱼塘
            </Link>
            <Link to="/quiz" className="hover:text-foreground">
              知识闯关
            </Link>
            <Link to="/ai-assistant" className="hover:text-foreground">
              AI 助手
            </Link>
          </nav>
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            Made with <Heart className="h-3 w-3 fill-destructive text-destructive" /> for 美育传播
          </p>
        </div>
      </div>
    </footer>
  );
}
