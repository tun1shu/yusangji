import { Accessibility, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useA11ySettings, type TextScale } from "@/hooks/use-a11y-settings";
import { playSound } from "@/lib/sound";

const SCALES: { value: TextScale; label: string }[] = [
  { value: "normal", label: "标准" },
  { value: "large", label: "大字" },
  { value: "xlarge", label: "超大" },
];

export function A11ySettingsButton() {
  const { settings, update } = useA11ySettings();

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label="无障碍与音效设置"
          className="min-h-11 min-w-11 rounded-full"
        >
          <Accessibility className="h-5 w-5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72 space-y-4">
        <h2 className="text-sm font-semibold text-foreground">无障碍与音效</h2>

        <div className="flex items-center justify-between gap-3">
          <Label htmlFor="a11y-sound" className="flex items-center gap-2 text-sm">
            {settings.sound ? (
              <Volume2 className="h-4 w-4 text-primary" />
            ) : (
              <VolumeX className="h-4 w-4 text-muted-foreground" />
            )}
            游戏音效
          </Label>
          <Switch
            id="a11y-sound"
            checked={settings.sound}
            onCheckedChange={(v) => {
              update({ sound: v });
              if (v) setTimeout(() => playSound("pop"), 30);
            }}
          />
        </div>

        <fieldset className="space-y-2">
          <legend className="text-sm text-foreground">文字大小</legend>
          <div className="flex gap-2" role="group" aria-label="文字大小">
            {SCALES.map((s) => (
              <Button
                key={s.value}
                size="sm"
                variant={settings.textScale === s.value ? "default" : "outline"}
                className="min-h-11 flex-1 rounded-full"
                aria-pressed={settings.textScale === s.value}
                onClick={() => update({ textScale: s.value })}
              >
                {s.label}
              </Button>
            ))}
          </div>
        </fieldset>

        <div className="flex items-center justify-between gap-3">
          <Label htmlFor="a11y-contrast" className="text-sm">
            高对比度
          </Label>
          <Switch
            id="a11y-contrast"
            checked={settings.highContrast}
            onCheckedChange={(v) => update({ highContrast: v })}
          />
        </div>

        <div className="flex items-center justify-between gap-3">
          <Label htmlFor="a11y-motion" className="text-sm">
            减少动画
          </Label>
          <Switch
            id="a11y-motion"
            checked={settings.reduceMotion}
            onCheckedChange={(v) => update({ reduceMotion: v })}
          />
        </div>

        <p className="text-xs text-muted-foreground">
          小提示：用 Tab 键在按钮之间移动，按 Enter 或空格选择；游戏中还可以用数字键 1-4 快速作答。
        </p>
      </PopoverContent>
    </Popover>
  );
}
