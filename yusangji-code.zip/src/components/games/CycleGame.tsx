import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, Lock, RotateCcw, Sparkles, Trophy, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FOUR_FISH_QUIZ, PUZZLES, shuffle, type CycleStep, type PuzzleId } from "@/lib/game-config";
import { recordResult } from "@/lib/game-difficulty";
import {
  CYCLE_LEVELS,
  SCORE_RULES,
  computeScore,
  isUnlocked,
  loadCycleProgress,
  saveLevelResult,
  type CycleProgress,
} from "@/lib/cycle-progress";
import { playSound } from "@/lib/sound";

export function CycleGame() {
  const [puzzleId, setPuzzleId] = useState<PuzzleId>("cycle");
  const puzzle = PUZZLES.find((p) => p.id === puzzleId) ?? PUZZLES[0]!;
  const STEPS = puzzle.steps;

  const [progress, setProgress] = useState<CycleProgress>({ cleared: [], total: 0, best: {} });
  const [levelId, setLevelId] = useState(1);
  const [tray, setTray] = useState<CycleStep[]>(STEPS);
  const [placed, setPlaced] = useState<CycleStep[]>([]);
  const [wrongId, setWrongId] = useState<string | null>(null);
  const [hits, setHits] = useState(0);
  const [misses, setMisses] = useState(0);
  const [saved, setSaved] = useState(false);
  const [quizIdx, setQuizIdx] = useState(0);
  const [quizPick, setQuizPick] = useState<number | null>(null);
  const [quizRight, setQuizRight] = useState(0);

  const quiz = puzzleId === "fourfish" ? FOUR_FISH_QUIZ : [];
  const hasQuiz = quiz.length > 0;
  const quizDone = quizIdx >= quiz.length;
  const quizBonus = quizRight * SCORE_RULES.quizCorrect;


  const level = CYCLE_LEVELS.find((l) => l.id === levelId) ?? CYCLE_LEVELS[0]!;

  const order = useMemo(
    () => (level.reverse ? [...STEPS].reverse() : STEPS),
    [level.reverse, STEPS],
  );

  useEffect(() => {
    const p = loadCycleProgress(puzzleId);
    setProgress(p);
    const next = CYCLE_LEVELS.find((l) => isUnlocked(l.id, p) && !p.cleared.includes(l.id));
    setLevelId(next?.id ?? CYCLE_LEVELS[CYCLE_LEVELS.length - 1]!.id);
  }, [puzzleId]);

  useEffect(() => {
    setTray(shuffle(STEPS));
    setPlaced([]);
    setWrongId(null);
    setHits(0);
    setMisses(0);
    setSaved(false);
    setQuizIdx(0);
    setQuizPick(null);
    setQuizRight(0);
  }, [levelId, puzzleId, STEPS]);

  const done = placed.length === STEPS.length;
  const nextStep = order[placed.length];
  const base = computeScore(hits, misses, STEPS.length);
  const result = { ...base, score: base.score + quizBonus };
  const allDone = done && (!hasQuiz || quizDone);

  useEffect(() => {
    if (allDone && !saved) {
      const total = hits + misses;
      recordResult("cycle", total > 0 ? hits / total : 1);
      setProgress(
        saveLevelResult(
          puzzleId,
          levelId,
          computeScore(hits, misses, STEPS.length).score + quizBonus,
        ),
      );
      setSaved(true);
    }
  }, [allDone, saved, hits, misses, levelId, puzzleId, STEPS.length, quizBonus]);

  function answerQuiz(i: number) {
    if (quizPick !== null) return;
    const item = quiz[quizIdx];
    if (!item) return;
    setQuizPick(i);
    if (i === item.answer) {
      setQuizRight((n) => n + 1);
      playSound("correct");
    } else {
      playSound("wrong");
    }
  }

  function nextQuiz() {
    setQuizPick(null);
    setQuizIdx((i) => i + 1);
  }

  function pick(id: string) {
    const step = tray.find((s) => s.id === id);
    if (!step) return;
    if (nextStep && step.id === nextStep.id) {
      setHits((h) => h + 1);
      setPlaced((p) => [...p, step]);
      setTray((t) => t.filter((s) => s.id !== id));
      setWrongId(null);
      playSound(placed.length + 1 === STEPS.length ? "win" : "correct");
    } else {
      setMisses((m) => m + 1);
      setWrongId(id);
      playSound("wrong");
      setTimeout(() => setWrongId(null), 700);
    }
  }

  function undo() {
    const last = placed[placed.length - 1];
    if (!last || !level.allowUndo) return;
    playSound("click");
    setPlaced((p) => p.slice(0, -1));
    setTray((t) => [...t, last]);
    setHits((h) => Math.max(0, h - 1));
  }

  function retry() {
    setTray(shuffle(STEPS));
    setPlaced([]);
    setWrongId(null);
    setHits(0);
    setMisses(0);
    setSaved(false);
    setQuizIdx(0);
    setQuizPick(null);
    setQuizRight(0);
  }


  const nextLevel = CYCLE_LEVELS.find((l) => l.id === levelId + 1);
  const clearedCount = progress.cleared.length;

  return (
    <div className="space-y-4">
      {/* 拼图选择 */}
      <div className="flex flex-wrap gap-2">
        {PUZZLES.map((p) => (
          <button
            key={p.id}
            onClick={() => setPuzzleId(p.id)}
            className={`min-h-11 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
              p.id === puzzleId
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-muted/30 text-foreground hover:bg-muted/60"
            }`}
          >
            {p.name}
          </button>
        ))}
      </div>
      <p className="text-sm text-muted-foreground">{puzzle.intro}</p>

      {/* 关卡进度 */}
      <div className="rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-semibold text-foreground">学习路径</h3>
          <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <Trophy className="h-3.5 w-3.5" />
            累计积分 {progress.total}
          </span>
        </div>
        <Progress
          value={(clearedCount / CYCLE_LEVELS.length) * 100}
          className="mt-3 h-2"
          aria-label="关卡完成进度"
        />
        <p className="mt-2 text-xs text-muted-foreground">
          已通关 {clearedCount} / {CYCLE_LEVELS.length} 关
        </p>

        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {CYCLE_LEVELS.map((l) => {
            const unlocked = isUnlocked(l.id, progress);
            const cleared = progress.cleared.includes(l.id);
            return (
              <button
                key={l.id}
                disabled={!unlocked}
                onClick={() => setLevelId(l.id)}
                className={`min-h-16 rounded-xl border p-3 text-left text-xs transition-colors ${
                  l.id === levelId
                    ? "border-primary bg-primary/10"
                    : "border-border bg-muted/30 hover:bg-muted/60"
                } ${unlocked ? "" : "cursor-not-allowed opacity-50"}`}
              >
                <span className="flex items-center gap-1 text-sm font-semibold text-foreground">
                  {!unlocked && <Lock className="h-3.5 w-3.5" />}
                  {cleared && <CheckCircle2 className="h-3.5 w-3.5 text-primary" />}
                  {l.name}
                </span>
                <span className="mt-1 block text-muted-foreground">
                  {unlocked ? `最佳 ${progress.best[l.id] ?? 0} 分` : "通关上一关后解锁"}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <p className="text-sm text-muted-foreground">{level.goal}</p>

      {/* 积分规则 */}
      <p className="rounded-xl bg-muted/40 px-4 py-2 text-xs text-muted-foreground">
        积分规则：放对一步 +{SCORE_RULES.correct} 分，放错一次 {SCORE_RULES.wrong} 分，通关 +
        {SCORE_RULES.levelClearBonus} 分，全程零失误再 +{SCORE_RULES.perfectBonus} 分。
      </p>

      {/* 本局进度 */}
      <div className="flex items-center gap-3">
        <Progress
          value={(placed.length / STEPS.length) * 100}
          className="h-2 flex-1"
          aria-label="本关拼图进度"
        />
        <span className="text-xs text-muted-foreground">
          {placed.length}/{STEPS.length} · 当前 {result.base} 分
        </span>
      </div>

      {level.showLabels && nextStep && !done && (
        <p className="text-sm text-primary">提示：下一步是「{nextStep.label}」</p>
      )}

      <div className="rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5">
        <h3 className="mb-3 text-sm font-semibold text-muted-foreground">
          {puzzle.name}{level.reverse ? "（逆向）" : ""}
        </h3>
        <div aria-live="polite" className="flex min-h-24 flex-wrap items-center gap-2">
          {placed.map((step, i) => (
            <div key={step.id} className="flex items-center gap-2">
              <div className="rounded-xl border border-primary bg-primary/10 px-3 py-2 text-center">
                <img
                  src={step.image}
                  alt={step.label}
                  loading="lazy"
                  className="mx-auto h-14 w-14 rounded-lg object-cover"
                />
                <div className="mt-1 text-xs font-medium text-foreground">{step.label}</div>
              </div>
              {i < placed.length - 1 && <span className="text-muted-foreground">→</span>}
            </div>
          ))}
          {placed.length > 0 && !done && <span className="text-muted-foreground">→</span>}
          {!done && (
            <div className="rounded-xl border-2 border-dashed border-border px-6 py-5 text-xs text-muted-foreground">
              ?
            </div>
          )}
          {done && <span className="text-muted-foreground">{puzzle.loopHint}</span>}
        </div>
      </div>

      {!done && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {tray.map((step) => (
            <button
              key={step.id}
              onClick={() => pick(step.id)}
              aria-label={`选择 ${step.label}`}
              className={`min-h-20 rounded-xl border p-4 text-center transition-all hover:scale-[1.02] ${
                wrongId === step.id
                  ? "border-destructive bg-destructive/10"
                  : "border-border bg-muted/30 hover:bg-muted/60"
              }`}
            >
              <img
                src={step.image}
                alt={step.label}
                loading="lazy"
                className="mx-auto h-20 w-20 rounded-lg object-cover sm:h-24 sm:w-24"
              />
              {level.showLabels && (
                <div className="mt-1 text-sm font-semibold text-foreground">{step.label}</div>
              )}
            </button>
          ))}
        </div>
      )}

      {placed.length > 0 && (
        <div className="space-y-2 rounded-2xl border border-border bg-card p-5 shadow-sm">
          {placed.map((step) => (
            <p key={step.id} className="flex items-start gap-2 text-sm text-muted-foreground">
              <img
                src={step.image}
                alt=""
                loading="lazy"
                className="h-10 w-10 shrink-0 rounded-md object-cover"
              />
              <span>
                <span className="font-medium text-foreground">{step.label}：</span>
                {step.detail}
              </span>
            </p>
          ))}
        </div>
      )}

      {done && hasQuiz && !quizDone && (
        <div className="space-y-3 rounded-2xl border border-primary/30 bg-primary/5 p-5">
          <p className="text-sm font-semibold text-foreground">
            水层分工小问答 {quizIdx + 1}/{quiz.length} · 答对一题 +{SCORE_RULES.quizCorrect} 分
          </p>
          <p className="text-base font-medium text-foreground">{quiz[quizIdx]!.q}</p>
          <div className="grid gap-2 sm:grid-cols-3">
            {quiz[quizIdx]!.options.map((opt, i) => {
              const isAnswer = i === quiz[quizIdx]!.answer;
              const state =
                quizPick === null
                  ? "border-border bg-card hover:bg-muted/60"
                  : isAnswer
                    ? "border-primary bg-primary/10"
                    : quizPick === i
                      ? "border-destructive bg-destructive/10"
                      : "border-border bg-card opacity-60";
              return (
                <button
                  key={opt}
                  onClick={() => answerQuiz(i)}
                  className={`min-h-11 rounded-xl border px-4 py-2 text-sm font-medium text-foreground transition-colors ${state}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
          {quizPick !== null && (
            <div className="space-y-2" aria-live="polite">
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">
                  {quizPick === quiz[quizIdx]!.answer ? "答对了！" : "再想想～"}
                </span>{" "}
                {quiz[quizIdx]!.explain}
              </p>
              <Button className="rounded-full" onClick={nextQuiz}>
                {quizIdx + 1 < quiz.length ? "下一题" : "查看学习反馈"}
              </Button>
            </div>
          )}
        </div>
      )}

      {allDone && (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-6 text-center">
          <Sparkles className="h-8 w-8 text-primary" />
          <p className="font-semibold text-foreground">
            通关啦！{puzzle.name} · {level.name} 完成。
          </p>
          <p className="text-2xl font-bold text-primary">+{result.score} 分</p>
          <p className="text-sm text-muted-foreground">
            基础 {result.base} 分 · 通关奖励 {SCORE_RULES.levelClearBonus} 分
            {result.perfect ? ` · 零失误奖励 ${SCORE_RULES.perfectBonus} 分` : ` · 失误 ${misses} 次`}
            {hasQuiz ? ` · 问答答对 ${quizRight}/${quiz.length} 得 ${quizBonus} 分` : ""}
          </p>
          {hasQuiz && (
            <p className="text-sm text-muted-foreground">
              {quizRight === quiz.length
                ? "水层分工掌握得很牢：鲢在上层滤浮游植物、鳙吃浮游动物、草鱼吃水草、青鱼清塘底。"
                : "再回顾一下：上层白鲢→中上层鳙鱼→中层草鱼→底层青鱼，各吃各的才能一塘水养四种鱼。"}
            </p>
          )}
          <p className="text-xs text-muted-foreground">
            本关最佳 {progress.best[levelId] ?? result.score} 分 · 累计 {progress.total} 分
          </p>

          <div className="flex flex-wrap justify-center gap-2">
            {nextLevel ? (
              <Button onClick={() => setLevelId(nextLevel.id)} className="rounded-full">
                进入{nextLevel.name}
              </Button>
            ) : (
              <span className="text-sm text-primary">全部关卡已完成，你已经是循环小专家！</span>
            )}
            <Button variant="outline" className="rounded-full" onClick={retry}>
              <RotateCcw className="mr-1 h-4 w-4" />
              再拼一次
            </Button>
          </div>
        </div>
      )}

      {!done && placed.length > 0 && level.allowUndo && (
        <Button variant="outline" className="rounded-full" onClick={undo}>
          <Undo2 className="mr-1 h-4 w-4" />
          撤回一步
        </Button>
      )}
    </div>
  );
}
