import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, RotateCcw, Sparkles, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FISH_CATEGORY_HINTS, shuffle } from "@/lib/game-config";
import {
  DIFFICULTY_LABEL,
  recommendDifficulty,
  recordResult,
  type Difficulty,
} from "@/lib/game-difficulty";
import { DifficultyPicker } from "@/components/games/DifficultyPicker";
import { playSound } from "@/lib/sound";
import type { Database } from "@/integrations/supabase/types";

type Fish = Database["public"]["Tables"]["fish_species"]["Row"];

const EASY_ROUNDS = 6;

export function FishSortGame({ species }: { species: Fish[] }) {
  const pool = useMemo(() => species.filter((s) => !!s.category), [species]);
  const allCategories = useMemo(
    () => Array.from(new Set(pool.map((s) => s.category as string))),
    [pool],
  );

  const [rec, setRec] = useState<{ difficulty: Difficulty; reason: string }>({
    difficulty: "easy",
    reason: "先从简单模式开始，熟悉玩法。",
  });
  const [difficulty, setDifficulty] = useState<Difficulty>("easy");

  const [round, setRound] = useState(0);
  const [order, setOrder] = useState<Fish[]>(pool);
  const [picked, setPicked] = useState<string | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongList, setWrongList] = useState<Fish[]>([]);

  const [saved, setSaved] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const r = recommendDifficulty("sort");
    setRec(r);
    setDifficulty(r.difficulty);
    setOrder(shuffle(pool));
    setHydrated(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const total = difficulty === "easy" ? Math.min(EASY_ROUNDS, order.length) : order.length;
  const current = order[round];
  const finished = round >= total;
  const isCorrect = picked !== null && current?.category === picked;

  // 简单模式：只给出正确答案 + 一个干扰项
  const options = useMemo(() => {
    if (!current || !hydrated) return allCategories;
    if (difficulty === "hard") return allCategories;
    const others = allCategories.filter((c) => c !== current.category);
    const distractor = others[Math.floor(Math.random() * others.length)];
    return shuffle([current.category as string, ...(distractor ? [distractor] : [])]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.id, difficulty, allCategories, hydrated]);


  // 键盘操作：数字键 1-4 选择答案，Enter 进入下一题
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (finished) return;
      if (picked === null) {
        const idx = Number(e.key) - 1;
        if (idx >= 0 && idx < options.length) choose(options[idx] as string);
      } else if (e.key === "Enter") {
        next();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  useEffect(() => {
    if (finished && !saved && total > 0) {
      recordResult("sort", correctCount / total);
      playSound("win");
      setRec(recommendDifficulty("sort"));
      setSaved(true);
    }
  }, [finished, saved, correctCount, total]);

  function reset(next: Difficulty = difficulty) {
    setDifficulty(next);
    setOrder(shuffle(pool));
    setRound(0);
    setPicked(null);
    setCorrectCount(0);
    setWrongList([]);
    setSaved(false);
  }

  function choose(cat: string) {
    setPicked(cat);
    playSound(cat === current?.category ? "correct" : "wrong");
  }

  function next() {
    playSound("click");
    if (isCorrect) setCorrectCount((c) => c + 1);
    else if (current) setWrongList((w) => (w.some((f) => f.id === current.id) ? w : [...w, current]));
    setPicked(null);
    setRound((r) => r + 1);
  }


  if (pool.length === 0) {
    return <p className="text-sm text-muted-foreground">暂时还没有可用的鱼类数据。</p>;
  }

  if (finished) {
    return (
      <div className="flex flex-col items-center gap-4 rounded-2xl border border-border bg-card p-10 text-center shadow-sm">
        <Sparkles className="h-10 w-10 text-primary" />
        <h3 className="text-xl font-bold text-foreground">全部完成啦！</h3>
        <p className="text-muted-foreground">
          {DIFFICULTY_LABEL[difficulty]}模式：你一共认对了 {correctCount} / {total} 条鱼
        </p>
        <p className="text-sm text-muted-foreground">{rec.reason}</p>

        {wrongList.length > 0 && (
          <div className="w-full space-y-2 rounded-xl border border-border bg-muted/30 p-4 text-left">
            <p className="text-sm font-semibold text-foreground">错题回顾（{wrongList.length} 条）</p>
            {wrongList.map((f) => (
              <div key={f.id} className="flex items-start gap-3">
                {f.image_url && (
                  <img
                    src={f.image_url}
                    alt={f.name}
                    loading="lazy"
                    className="h-12 w-12 shrink-0 rounded-md object-cover"
                  />
                )}
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">
                    {f.name}（{f.category}）：
                  </span>
                  {f.description ?? (f.category ? FISH_CATEGORY_HINTS[f.category] : "")}
                </p>
              </div>
            ))}
          </div>
        )}

        <div className="flex flex-wrap justify-center gap-2">
          <Button onClick={() => reset()} className="rounded-full">
            <RotateCcw className="mr-1 h-4 w-4" />
            再玩一次
          </Button>
          <Button
            variant="outline"
            className="rounded-full"
            onClick={() => reset(rec.difficulty)}
          >
            按推荐玩{DIFFICULTY_LABEL[rec.difficulty]}模式
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <DifficultyPicker
        value={difficulty}
        onChange={(d) => reset(d)}
        recommended={rec.difficulty}
        reason={rec.reason}
      />

      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>
          第 {round + 1} / {total} 条
        </span>
        <span>已认对 {correctCount}</span>
      </div>
      <Progress value={(round / total) * 100} className="h-2" />

      <div className="rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-6">
        <div className="flex flex-col items-center gap-4">
          {current?.image_url ? (
            <img
              src={current.image_url}
              alt={current.name}
              className="h-40 w-full max-w-md rounded-xl object-cover sm:h-48"
            />
          ) : (
            <div className="flex h-40 w-full max-w-md items-center justify-center rounded-xl bg-muted text-5xl sm:h-48">
              🐟
            </div>
          )}
          <h3 className="text-2xl font-bold text-foreground">
            {difficulty === "easy" ? current?.name : "这是哪一类鱼？"}
          </h3>
          <p className="text-center text-sm text-muted-foreground">
            {difficulty === "easy" ? "它属于下面哪一类？" : "先看图片判断，再选择所属类别"}
          </p>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          {options.map((cat, i) => {
            const chosen = picked === cat;
            const rightOne = picked !== null && cat === current?.category;
            return (
              <button
                key={cat}
                disabled={picked !== null}
                onClick={() => choose(cat)}
                aria-label={`选择类别 ${cat}，快捷键 ${i + 1}`}
                className={`min-h-16 rounded-xl border p-4 text-left transition-all ${
                  rightOne
                    ? "border-primary bg-primary/10"
                    : chosen
                      ? "border-destructive bg-destructive/10"
                      : "border-border bg-muted/30 hover:bg-muted/60"
                }`}
              >
                <div className="flex items-center gap-2">
                  {rightOne && <CheckCircle2 className="h-4 w-4 text-primary" />}
                  {chosen && !rightOne && <XCircle className="h-4 w-4 text-destructive" />}
                  <span className="font-semibold text-foreground">
                    <span className="mr-1 text-xs text-muted-foreground">{i + 1}.</span>
                    {cat}
                  </span>
                </div>
                {difficulty === "easy" && (
                  <p className="mt-1 text-xs text-muted-foreground">{FISH_CATEGORY_HINTS[cat]}</p>
                )}
              </button>
            );
          })}
        </div>

        {picked !== null && current && (
          <div
            className={`mt-5 rounded-xl border p-4 ${
              isCorrect ? "border-primary/40 bg-primary/5" : "border-destructive/40 bg-destructive/5"
            }`}
          >
            <p aria-live="polite" className="flex items-center gap-2 text-base font-semibold text-foreground">
              {isCorrect ? (
                <CheckCircle2 className="h-5 w-5 text-primary" />
              ) : (
                <XCircle className="h-5 w-5 text-destructive" />
              )}
              {isCorrect
                ? `答对啦！这是「${current.name}」`
                : `再想想～它其实是「${current.name}」`}
            </p>

            <p className="mt-1 text-sm text-muted-foreground">
              正确类别：
              <span className="font-medium text-foreground">{current.category}</span>
              {current.category && FISH_CATEGORY_HINTS[current.category]
                ? `——${FISH_CATEGORY_HINTS[current.category]}`
                : ""}
              {!isCorrect && picked ? `（你选的是「${picked}」）` : ""}
            </p>

            <div className="mt-3 space-y-2 rounded-lg bg-background/70 p-3">
              <p className="text-xs font-semibold text-primary">知识解析</p>
              {current.scientific_name && (
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">学名：</span>
                  {current.scientific_name}
                </p>
              )}
              {current.aliases && current.aliases.length > 0 && (
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">别名：</span>
                  {current.aliases.join("、")}
                </p>
              )}
              {current.habitat && (
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">栖息水层：</span>
                  {current.habitat}
                </p>
              )}
              {current.diet && (
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">食性：</span>
                  {current.diet}
                </p>
              )}
              {current.description && (
                <p className="text-sm text-muted-foreground">{current.description}</p>
              )}
              {current.fun_facts && current.fun_facts.length > 0 && (
                <p className="rounded-md bg-primary/10 px-3 py-2 text-sm text-foreground">
                  💡 冷知识：{current.fun_facts[0]}
                </p>
              )}
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {!isCorrect && difficulty === "easy" && (
                <Button variant="outline" className="rounded-full" onClick={() => setPicked(null)}>
                  再试一次
                </Button>
              )}
              <Button className="rounded-full" onClick={next}>
                下一条
              </Button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
