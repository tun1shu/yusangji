import { Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DIFFICULTY_LABEL, type Difficulty } from "@/lib/game-difficulty";

export function DifficultyPicker({
  value,
  onChange,
  recommended,
  reason,
}: {
  value: Difficulty;
  onChange: (d: Difficulty) => void;
  recommended: Difficulty;
  reason: string;
}) {
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-start gap-2 text-sm text-muted-foreground">
        <Lightbulb className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
        <span>
          推荐<span className="font-semibold text-foreground">{DIFFICULTY_LABEL[recommended]}</span>
          模式：{reason}
        </span>
      </div>
      <div className="flex gap-2">
        {(["easy", "hard"] as Difficulty[]).map((d) => (
          <Button
            key={d}
            size="sm"
            variant={value === d ? "default" : "outline"}
            className="rounded-full"
            onClick={() => onChange(d)}
          >
            {DIFFICULTY_LABEL[d]}
            {recommended === d && <span className="ml-1 text-xs">·推荐</span>}
          </Button>
        ))}
      </div>
    </div>
  );
}
