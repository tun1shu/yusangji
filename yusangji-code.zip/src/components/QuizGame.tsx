import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useServerFn } from "@tanstack/react-start";
import { saveQuizAttempt } from "@/lib/user.functions";
import { CheckCircle2, XCircle, Trophy, RotateCcw } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type Question = Database["public"]["Tables"]["quiz_questions"]["Row"];

export function QuizGame({ questions, userId }: { questions: Question[]; userId: string | null }) {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<{ questionId: string; correct: boolean; selected: number }[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);
  const saveAttempt = useServerFn(saveQuizAttempt);

  const current = questions[index];
  if (!current) return null;
  const progress = questions.length ? ((index + (submitted ? 1 : 0)) / questions.length) * 100 : 0;

  const handleSelect = (i: number) => {
    if (submitted) return;
    setSelected(i);
  };

  const handleSubmit = () => {
    if (selected == null || !current) return;
    const correct = selected === current.correct_index;
    if (correct) setScore((s) => s + 1);
    setAnswers((prev) => [...prev, { questionId: current.id, correct, selected }]);
    setSubmitted(true);
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex((i) => i + 1);
      setSelected(null);
      setSubmitted(false);
    } else {
      setShowResult(true);
      if (userId) {
        setSaving(true);
        saveAttempt({
          data: {
            score: score + (selected === current.correct_index ? 1 : 0),
            total: questions.length,
            answers: answers,
          },
        }).finally(() => setSaving(false));
      }
    }
  };

  const restart = () => {
    setIndex(0);
    setSelected(null);
    setShowResult(false);
    setScore(0);
    setAnswers([]);
    setSubmitted(false);
  };

  if (questions.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">暂无题目</CardContent>
      </Card>
    );
  }

  if (showResult) {
    const finalScore = score;
    const percentage = Math.round((finalScore / questions.length) * 100);
    return (
      <Card className="text-center">
        <CardHeader>
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <Trophy className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="mt-4 text-2xl">闯关完成！</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-4xl font-bold text-foreground">
            {finalScore}/{questions.length}
          </p>
          <p className="text-muted-foreground">正确率 {percentage}%</p>
          <p className="text-sm text-muted-foreground">
            {percentage >= 80 ? "太棒了，你是渔桑小达人！" : percentage >= 60 ? "继续加油，已经很棒了！" : "再试一次，知识会更牢固！"}
          </p>
          <Button onClick={restart} className="rounded-full">
            <RotateCcw className="mr-2 h-4 w-4" />
            再闯一次
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-sand/40">
        <div className="mb-2 flex items-center justify-between">
          <Badge variant="outline">
            第 {index + 1} / {questions.length} 题
          </Badge>
          {current.difficulty && <Badge variant="secondary">{current.difficulty}</Badge>}
        </div>
        <Progress value={progress} className="h-2" />
      </CardHeader>
      <CardContent className="space-y-4 p-6">
        <h3 className="text-xl font-bold leading-relaxed text-foreground">{current.question}</h3>
        <div className="grid gap-3">
          {current.options.map((option, i) => {
            const isSelected = selected === i;
            const isCorrect = i === current.correct_index;
            let variant: "default" | "outline" | "secondary" = "outline";
            let icon = null;
            if (submitted) {
              if (isCorrect) {
                variant = "default";
                icon = <CheckCircle2 className="ml-2 h-4 w-4" />;
              } else if (isSelected) {
                variant = "secondary";
                icon = <XCircle className="ml-2 h-4 w-4" />;
              }
            } else if (isSelected) {
              variant = "default";
            }
            return (
              <Button
                key={i}
                variant={variant}
                onClick={() => handleSelect(i)}
                disabled={submitted}
                className="h-auto justify-start px-4 py-3 text-left"
              >
                <span className="mr-3 inline-flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-muted text-xs font-bold">
                  {String.fromCharCode(65 + i)}
                </span>
                <span className="flex-1">{option}</span>
                {icon}
              </Button>
            );
          })}
        </div>

        {submitted && current.explanation && (
          <div className="rounded-xl bg-accent/40 p-4 text-sm text-foreground">
            <span className="font-bold">解析：</span>
            {current.explanation}
          </div>
        )}

        <div className="flex justify-end gap-3 pt-2">
          {!submitted ? (
            <Button onClick={handleSubmit} disabled={selected == null} className="rounded-full">
              确认答案
            </Button>
          ) : (
            <Button onClick={handleNext} disabled={saving} className="rounded-full">
              {index < questions.length - 1 ? "下一题" : "查看结果"}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
