import ReactMarkdown from "react-markdown";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Database } from "@/integrations/supabase/types";

export type Article = Database["public"]["Tables"]["culture_articles"]["Row"];

export function articleCover(article: Article) {
  return article.cover_url || "https://placehold.co/800x400/e2e8f0/64748b?text=暂无封面";
}

export function ArticleDetail({ article }: { article: Article }) {
  return article.content ? (
    <article className="prose prose-sm max-w-none dark:prose-invert">
      <ReactMarkdown>{article.content}</ReactMarkdown>
    </article>
  ) : (
    <p className="text-sm text-muted-foreground">暂无正文内容。</p>
  );
}

export function ArticleCard({ article, onOpen }: { article: Article; onOpen?: () => void }) {
  const cover = articleCover(article);

  return (
    <Card className="group h-full overflow-hidden transition-shadow hover:shadow-md">
      <button
        type="button"
        onClick={onOpen}
        aria-label={`查看《${article.title}》的内容`}
        className="block w-full cursor-pointer"
      >
        <div className="aspect-video overflow-hidden bg-muted">
          <img
            src={cover}
            alt={article.title}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
      </button>
      <CardHeader className="p-4 pb-2">
        {article.category && <Badge variant="secondary">{article.category}</Badge>}
        <CardTitle className="text-lg">{article.title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="line-clamp-2 text-sm text-muted-foreground">{article.summary || "点击图片阅读全文"}</p>
        <button
          type="button"
          onClick={onOpen}
          className="mt-2 text-xs font-medium text-leaf hover:underline"
        >
          点击图片看知识
        </button>
      </CardContent>
    </Card>
  );
}
