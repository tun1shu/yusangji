import { useEffect, useState } from "react";

export type TextScale = "normal" | "large" | "xlarge";

export type A11ySettings = {
  sound: boolean;
  textScale: TextScale;
  highContrast: boolean;
  reduceMotion: boolean;
};

export const DEFAULT_A11Y: A11ySettings = {
  sound: true,
  textScale: "normal",
  highContrast: false,
  reduceMotion: false,
};

const KEY = "yusang-a11y";
const EVENT = "yusang-a11y-change";

export function readA11y(): A11ySettings {
  if (typeof window === "undefined") return DEFAULT_A11Y;
  try {
    return { ...DEFAULT_A11Y, ...(JSON.parse(window.localStorage.getItem(KEY) ?? "{}") as object) };
  } catch {
    return DEFAULT_A11Y;
  }
}

export function applyA11y(s: A11ySettings) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.toggle("a11y-text-large", s.textScale === "large");
  root.classList.toggle("a11y-text-xlarge", s.textScale === "xlarge");
  root.classList.toggle("a11y-contrast", s.highContrast);
  root.classList.toggle("a11y-reduce-motion", s.reduceMotion);
}

export function useA11ySettings() {
  const [settings, setSettings] = useState<A11ySettings>(DEFAULT_A11Y);

  useEffect(() => {
    const next = readA11y();
    setSettings(next);
    applyA11y(next);
    const onChange = (e: Event) => {
      const detail = (e as CustomEvent<A11ySettings>).detail;
      setSettings(detail);
      applyA11y(detail);
    };
    window.addEventListener(EVENT, onChange);
    return () => window.removeEventListener(EVENT, onChange);
  }, []);

  function update(patch: Partial<A11ySettings>) {
    const next = { ...readA11y(), ...patch };
    try {
      window.localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
    window.dispatchEvent(new CustomEvent<A11ySettings>(EVENT, { detail: next }));
  }

  return { settings, update };
}
