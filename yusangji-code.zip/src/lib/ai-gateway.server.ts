import { createOpenAI } from "@ai-sdk/openai";

export function createLovableAiGateway() {
  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) {
    throw new Error("Missing LOVABLE_API_KEY");
  }

  return createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: {
      "Lovable-API-Key": apiKey,
    },
  });
}
