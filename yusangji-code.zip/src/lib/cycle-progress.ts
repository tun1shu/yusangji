import type { PuzzleId } from "@/lib/game-config";

export type CycleLevel = {
  id: number;
  name: string;
  goal: string;
  reverse: boolean;
  showLabels: boolean;
  allowUndo: boolean;
};

export const CYCLE_LEVELS: CycleLevel[] = [
  {
    id: 1,
    name: "第 1 关 · 认识循环",
    goal: "按正确顺序依次点击卡片拼出链条，卡片带有文字提示。",
    reverse: false,
    showLabels: true,
    allowUndo: true,
  },
  {
    id: 2,
    name: "第 2 关 · 看图排序",
    goal: "卡片只剩图案，凭记忆按正确顺序排列。",
    reverse: false,
    showLabels: false,
    allowUndo: true,
  },
  {
    id: 3,
    name: "第 3 关 · 逆向推演",
    goal: "倒着推回起点，想清楚每一步之间的关系。",
    reverse: true,
    showLabels: false,
    allowUndo: false,
  },
];

/** 积分规则 */
export const SCORE_RULES = {
  correct: 20,
  wrong: -5,
  perfectBonus: 30,
  levelClearBonus: 10,
  quizCorrect: 15,
};


const KEY_BASE = "yusang.cycle.progress";

function keyFor(puzzle: PuzzleId) {
  return puzzle === "cycle" ? KEY_BASE : `${KEY_BASE}.${puzzle}`;
}

export type CycleProgress = {
  cleared: number[];
  total: number;
  best: Record<number, number>;
};

const EMPTY: CycleProgress = { cleared: [], total: 0, best: {} };

export function loadCycleProgress(puzzle: PuzzleId = "cycle"): CycleProgress {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = window.localStorage.getItem(keyFor(puzzle));
    if (!raw) return EMPTY;
    const parsed = JSON.parse(raw) as Partial<CycleProgress>;
    return {
      cleared: Array.isArray(parsed.cleared) ? parsed.cleared : [],
      total: typeof parsed.total === "number" ? parsed.total : 0,
      best: parsed.best && typeof parsed.best === "object" ? parsed.best : {},
    };
  } catch {
    return EMPTY;
  }
}

export function saveLevelResult(
  puzzle: PuzzleId,
  levelId: number,
  score: number,
): CycleProgress {
  const prev = loadCycleProgress(puzzle);
  const next: CycleProgress = {
    cleared: prev.cleared.includes(levelId) ? prev.cleared : [...prev.cleared, levelId],
    total: prev.total + Math.max(0, score),
    best: { ...prev.best, [levelId]: Math.max(prev.best[levelId] ?? 0, score) },
  };
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(keyFor(puzzle), JSON.stringify(next));
    } catch {
      /* ignore */
    }
  }
  return next;
}

export function isUnlocked(levelId: number, progress: CycleProgress) {
  return levelId === 1 || progress.cleared.includes(levelId - 1);
}

export function computeScore(hits: number, misses: number, stepCount: number) {
  const base = hits * SCORE_RULES.correct + misses * SCORE_RULES.wrong;
  const perfect = misses === 0 && hits === stepCount;
  const bonus = (perfect ? SCORE_RULES.perfectBonus : 0) + SCORE_RULES.levelClearBonus;
  return { base: Math.max(0, base), bonus, perfect, score: Math.max(0, base) + bonus };
}
