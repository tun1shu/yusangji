/** 轻量音效：用 Web Audio 合成，无需音频文件，适合中小学生的柔和提示音。 */

export type SoundName = "click" | "correct" | "wrong" | "win" | "pop";

let ctx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Ctor =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  if (!ctx) ctx = new Ctor();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

const NOTES: Record<SoundName, { freqs: number[]; dur: number; type: OscillatorType; gain: number }> = {
  click: { freqs: [660], dur: 0.07, type: "sine", gain: 0.05 },
  pop: { freqs: [520, 780], dur: 0.09, type: "triangle", gain: 0.05 },
  correct: { freqs: [660, 880], dur: 0.12, type: "sine", gain: 0.07 },
  wrong: { freqs: [300, 220], dur: 0.16, type: "sine", gain: 0.06 },
  win: { freqs: [523, 659, 784, 1047], dur: 0.13, type: "triangle", gain: 0.07 },
};

const SOUND_KEY = "yusang-a11y";

function soundEnabled(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = window.localStorage.getItem(SOUND_KEY);
    if (!raw) return true;
    const parsed = JSON.parse(raw) as { sound?: boolean };
    return parsed.sound !== false;
  } catch {
    return true;
  }
}

export function playSound(name: SoundName) {
  if (!soundEnabled()) return;
  const audio = getCtx();
  if (!audio) return;
  const cfg = NOTES[name];
  cfg.freqs.forEach((freq, i) => {
    const start = audio.currentTime + i * cfg.dur;
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = cfg.type;
    osc.frequency.setValueAtTime(freq, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(cfg.gain, start + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + cfg.dur);
    osc.connect(gain).connect(audio.destination);
    osc.start(start);
    osc.stop(start + cfg.dur + 0.02);
  });
}
