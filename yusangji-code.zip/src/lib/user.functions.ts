import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

type FavoriteInsert = Database["public"]["Tables"]["user_favorites"]["Insert"];

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("profiles")
      .select("*")
      .eq("id", context.userId)
      .single();
    if (error && error.code !== "PGRST116") throw error;
    return data;
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: unknown) =>
      z
        .object({
          nickname: z.string().max(50).optional(),
          grade: z.string().max(30).optional(),
          avatar_url: z.string().url().max(500).optional().or(z.literal("")),
        })
        .parse(input)
  )
  .handler(async ({ data, context }) => {
    const payload = {
      id: context.userId,
      nickname: data.nickname ?? null,
      grade: data.grade ?? null,
      avatar_url: data.avatar_url || null,
      updated_at: new Date().toISOString(),
    };
    const { error } = await context.supabase.from("profiles").upsert(payload);
    if (error) throw error;
    return { ok: true };
  });

export const listMyFavorites = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("user_favorites")
      .select("*")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  });

export const addFavorite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: unknown) =>
      z
        .object({
          target_id: z.string().uuid(),
          target_type: z.enum(["fish", "article"]),
        })
        .parse(input)
  )
  .handler(async ({ data, context }) => {
    const row: FavoriteInsert = {
      user_id: context.userId,
      target_id: data.target_id,
      target_type: data.target_type,
    };
    const { error } = await context.supabase.from("user_favorites").insert(row);
    if (error) throw error;
    return { ok: true };
  });

export const removeFavorite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: unknown) =>
      z
        .object({
          target_id: z.string().uuid(),
          target_type: z.enum(["fish", "article"]),
        })
        .parse(input)
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("user_favorites")
      .delete()
      .eq("user_id", context.userId)
      .eq("target_id", data.target_id)
      .eq("target_type", data.target_type);
    if (error) throw error;
    return { ok: true };
  });

export const listMyCheckIns = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("check_ins")
      .select("*")
      .eq("user_id", context.userId)
      .order("checked_in_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  });

export const checkInToday = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: unknown) =>
      z
        .object({ note: z.string().max(200).optional() })
        .default({})
        .parse(input)
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("check_ins").upsert(
      {
        user_id: context.userId,
        checked_in_at: new Date().toISOString().slice(0, 10),
        note: data.note ?? null,
      },
      { onConflict: "user_id, checked_in_at" }
    );
    if (error) throw error;
    return { ok: true };
  });

export const saveQuizAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: unknown) =>
      z
        .object({
          score: z.number().int().min(0),
          total: z.number().int().min(1),
          answers: z.array(z.record(z.string(), z.any())),
        })
        .parse(input)
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("quiz_attempts").insert({
      user_id: context.userId,
      score: data.score,
      total: data.total,
      answers: data.answers,
    });
    if (error) throw error;
    return { ok: true };
  });

export const listMyQuizAttempts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("quiz_attempts")
      .select("*")
      .eq("user_id", context.userId)
      .order("completed_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  });

export const claimFirstAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: existing } = await context.supabase
      .from("user_roles")
      .select("id")
      .eq("role", "admin")
      .limit(1);
    if (existing && existing.length > 0) {
      return { ok: false, reason: "already_has_admin" };
    }
    const { error } = await context.supabase.from("user_roles").insert({
      user_id: context.userId,
      role: "admin",
    });
    if (error) throw error;
    return { ok: true };
  });

export const getMyRoles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", context.userId);
    if (error) throw error;
    return (data ?? []).map((r) => r.role);
  });
