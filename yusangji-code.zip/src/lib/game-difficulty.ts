export type Difficulty = "easy" | "hard";
export type GameKey = "sort" | "cycle";

const STORAGE_KEY = "yusang-game-perf";

export type GamePerf = {
  plays: number;
  lastAccuracy: number; // 0 - 1
  bestAccuracy: number;
};

type PerfMap = Partial<Record<GameKey, GamePerf>>;

function readAll(): PerfMap {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "{}") as PerfMap;
  } catch {
    return {};
  }
}

export function getPerf(game: GameKey): GamePerf | null {
  return readAll()[game] ?? null;
}

export function recordResult(game: GameKey, accuracy: number): GamePerf {
  const all = readAll();
  const prev = all[game];
  const next: GamePerf = {
    plays: (prev?.plays ?? 0) + 1,
    lastAccuracy: accuracy,
    bestAccuracy: Math.max(prev?.bestAccuracy ?? 0, accuracy),
  };
  all[game] = next;
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
    } catch {
      /* ignore */
    }
  }
  return next;
}

/** 根据历史表现推荐难度：正确率高且玩过一次以上 → 进阶 */
export function recommendDifficulty(game: GameKey): {
  difficulty: Difficulty;
  reason: string;
} {
  const perf = getPerf(game);
  if (!perf || perf.plays === 0) {
    return { difficulty: "easy", reason: "第一次玩，先从简单模式熟悉一下吧。" };
  }
  const pct = Math.round(perf.lastAccuracy * 100);
  if (perf.lastAccuracy >= 0.8) {
    return { difficulty: "hard", reason: `上次正确率 ${pct}%，可以挑战进阶模式啦！` };
  }
  if (perf.lastAccuracy >= 0.5) {
    return { difficulty: "easy", reason: `上次正确率 ${pct}%，再用简单模式巩固一次吧。` };
  }
  return { difficulty: "easy", reason: `上次正确率 ${pct}%，别着急，简单模式慢慢来。` };
}

export const DIFFICULTY_LABEL: Record<Difficulty, string> = {
  easy: "简单",
  hard: "进阶",
};
