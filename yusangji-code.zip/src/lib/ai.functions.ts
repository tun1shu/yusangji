import { createServerFn } from "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGateway } from "./ai-gateway.server";

const AskInput = z.object({
  question: z.string().min(1).max(1000),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string(),
      })
    )
    .default([]),
});

export const askYuSangAssistant = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => AskInput.parse(input))
  .handler(async ({ data }) => {
    const openai = createLovableAiGateway();

    const system =
      "你是「渔桑记」的 AI 科普助手，面向中小学生讲解渔桑文化、鱼类知识和桑基鱼塘生态。回答要亲切、易懂、准确，控制在 300 字以内，必要时使用条目或比喻。不要回答与渔桑文化、鱼类、生态无关的问题，请礼貌地引导用户回到主题。";

    const messages = [
      ...data.history.map((m) => ({ role: m.role, content: m.content })),
      { role: "user" as const, content: data.question },
    ];

    const result = await generateText({
      model: openai.responses("openai/gpt-5.6-sol"),
      system,
      messages,
      providerOptions: {
        openai: {
          reasoning_effort: "none",
        },
      },
    });

    return { answer: result.text };
  });
