import cycleMulberry from "@/assets/cycle-mulberry.jpg.asset.json";
import cycleSilkworm from "@/assets/cycle-silkworm.jpg.asset.json";
import cycleWaste from "@/assets/cycle-waste.jpg.asset.json";
import cycleFish from "@/assets/cycle-fish.jpg.asset.json";
import cycleMud from "@/assets/cycle-mud.jpg.asset.json";
import fishQingyu from "@/assets/puzzle-qingyu.webp.asset.json";
import fishCaoyu from "@/assets/puzzle-caoyu.webp.asset.json";
import fishBailian from "@/assets/puzzle-lianyu.webp.asset.json";
import fishYongyu from "@/assets/puzzle-yongyu.webp.asset.json";



export type CycleStep = {
  id: string;
  label: string;
  icon: string;
  image: string;
  detail: string;
};

// 桑基鱼塘循环拼图：正确顺序
export const CYCLE_STEPS: CycleStep[] = [
  { id: "mulberry", label: "种桑", icon: "🌿", image: cycleMulberry.url, detail: "塘基上种桑树，桑叶用来养蚕，桑根还能固住塘埂。" },
  { id: "silkworm", label: "养蚕", icon: "🐛", image: cycleSilkworm.url, detail: "蚕吃桑叶长大吐丝，丝可以缫丝织绸。" },
  { id: "waste", label: "蚕沙落塘", icon: "🍂", image: cycleWaste.url, detail: "蚕沙（蚕粪）营养丰富，倒进鱼塘成为鱼的饲料。" },
  { id: "fish", label: "养鱼", icon: "🐟", image: cycleFish.url, detail: "多种鱼分层混养，把蚕沙和浮游生物吃掉，水质更清。" },
  { id: "mud", label: "挖塘泥肥桑", icon: "🟫", image: cycleMud.url, detail: "鱼粪沉积成塘泥，挖出后回到塘基肥桑，循环重新开始。" },
];


// 四大家鱼养殖体系拼图：按水层从上到下的混养顺序
export const FOUR_FISH_STEPS: CycleStep[] = [
  { id: "bailian", label: "鲢鱼 · 上层", icon: "🐟", image: fishBailian.url, detail: "白鲢生活在水体上层，滤食浮游植物（绿藻），能把发绿的水“喝”清。" },
  { id: "yongyu", label: "鳙鱼 · 中上层", icon: "🐟", image: fishYongyu.url, detail: "鳙鱼（花鲢、胖头鱼）在中上层，主要吃浮游动物，与白鲢分工不抢食。" },
  { id: "caoyu", label: "草鱼 · 中层", icon: "🐟", image: fishCaoyu.url, detail: "草鱼在中层活动，吃水草和岸边青草，它的粪便还能肥水养浮游生物。" },
  { id: "qingyu", label: "青鱼 · 底层", icon: "🐟", image: fishQingyu.url, detail: "青鱼在塘底，吃螺蛳、河蚌等底栖动物，清理塘底、减少病害。" },
];

export type PuzzleId = "cycle" | "fourfish";

export const PUZZLES: { id: PuzzleId; name: string; intro: string; steps: CycleStep[]; loopHint: string }[] = [
  {
    id: "cycle",
    name: "桑基鱼塘循环",
    intro: "把「种桑 → 养蚕 → 蚕沙落塘 → 养鱼 → 塘泥肥桑」串成零废弃的循环。",
    steps: CYCLE_STEPS,
    loopHint: "↻ 回到桑树",
  },
  {
    id: "fourfish",
    name: "四大家鱼养殖体系",
    intro: "按水层从上到下排出鲢、鳙、草、青的混养分工，理解“一塘水养四种鱼”。",
    steps: FOUR_FISH_STEPS,
    loopHint: "🪣 一塘水，四层鱼",
  },
];

export const FISH_CATEGORY_HINTS: Record<string, string> = {
  四大家鱼: "青、草、鲢、鳙——中国传统混养的四种主力鱼。",
  太湖三白: "太湖白鱼、白虾、银鱼，体色银白的太湖特产。",
  名贵淡水鱼: "肉质细嫩、价格较高的淡水鱼，如鳜鱼。",
  常见淡水鱼: "河塘里最常见的鱼，如鲤鱼、鲫鱼。",
};

export function shuffle<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const a = arr[i]!;
    arr[i] = arr[j]!;
    arr[j] = a;
  }
  return arr;
}

// 四大家鱼通关后的水层分工快速问答
export type LayerQuizItem = {
  q: string;
  options: string[];
  answer: number;
  explain: string;
};

export const FOUR_FISH_QUIZ: LayerQuizItem[] = [
  {
    q: "水面发绿、浮游植物太多时，主要靠哪种鱼来“喝清”池水？",
    options: ["草鱼", "白鲢", "青鱼"],
    answer: 1,
    explain: "白鲢住在上层，专门滤食浮游植物（绿藻），是池塘的“净水器”。",
  },
  {
    q: "塘底的螺蛳、河蚌由谁负责清理？",
    options: ["鳙鱼", "白鲢", "青鱼"],
    answer: 2,
    explain: "青鱼在底层活动，牙齿强壮，吃螺蛳河蚌，帮助清理塘底、减少病害。",
  },
];
