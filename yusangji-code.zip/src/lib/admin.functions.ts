import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const fishSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(100),
  scientific_name: z.string().max(100).optional().or(z.literal("")),
  aliases: z.array(z.string()).default([]),
  description: z.string().optional().or(z.literal("")),
  habitat: z.string().optional().or(z.literal("")),
  diet: z.string().optional().or(z.literal("")),
  fun_facts: z.array(z.string()).default([]),
  image_url: z.string().url().max(500).optional().or(z.literal("")),
  category: z.string().max(50).optional().or(z.literal("")),
  difficulty: z.string().max(20).optional().or(z.literal("")),
});

const articleSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().min(1).max(200),
  slug: z.string().min(1).max(200),
  summary: z.string().optional().or(z.literal("")),
  content: z.string().optional().or(z.literal("")),
  cover_url: z.string().url().max(500).optional().or(z.literal("")),
  category: z.string().max(50).optional().or(z.literal("")),
  order_index: z.number().int().default(0),
});

const quizSchema = z.object({
  id: z.string().uuid().optional(),
  question: z.string().min(1).max(500),
  options: z.array(z.string().min(1)).min(2).max(6),
  correct_index: z.number().int().min(0).max(5),
  explanation: z.string().optional().or(z.literal("")),
  related_fish_id: z.string().uuid().optional().or(z.literal("")),
  difficulty: z.string().max(20).optional().or(z.literal("")),
  category: z.string().max(50).optional().or(z.literal("")),
});

function ensureAuth(context: { userId: string }) {
  if (!context.userId) throw new Error("Unauthorized");
}

export const upsertFish = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => fishSchema.parse(input))
  .handler(async ({ data, context }) => {
    ensureAuth(context);
    const payload = {
      name: data.name,
      scientific_name: data.scientific_name || null,
      aliases: data.aliases,
      description: data.description || null,
      habitat: data.habitat || null,
      diet: data.diet || null,
      fun_facts: data.fun_facts,
      image_url: data.image_url || null,
      category: data.category || null,
      difficulty: data.difficulty || null,
      ...(data.id ? { id: data.id } : {}),
    };
    const { error } = await context.supabase.from("fish_species").upsert(payload);
    if (error) throw error;
    return { ok: true };
  });

export const deleteFish = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    ensureAuth(context);
    const { error } = await context.supabase.from("fish_species").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

export const upsertArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => articleSchema.parse(input))
  .handler(async ({ data, context }) => {
    ensureAuth(context);
    const payload = {
      title: data.title,
      slug: data.slug,
      order_index: data.order_index,
      summary: data.summary || null,
      content: data.content || null,
      cover_url: data.cover_url || null,
      category: data.category || null,
      ...(data.id ? { id: data.id } : {}),
    };
    const { error } = await context.supabase.from("culture_articles").upsert(payload);
    if (error) throw error;
    return { ok: true };
  });

export const deleteArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    ensureAuth(context);
    const { error } = await context.supabase.from("culture_articles").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

export const upsertQuiz = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => quizSchema.parse(input))
  .handler(async ({ data, context }) => {
    ensureAuth(context);
    const payload = {
      question: data.question,
      options: data.options,
      correct_index: data.correct_index,
      explanation: data.explanation || null,
      related_fish_id: data.related_fish_id || null,
      difficulty: data.difficulty || null,
      category: data.category || null,
      ...(data.id ? { id: data.id } : {}),
    };
    const { error } = await context.supabase.from("quiz_questions").upsert(payload);
    if (error) throw error;
    return { ok: true };
  });

export const deleteQuiz = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    ensureAuth(context);
    const { error } = await context.supabase.from("quiz_questions").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });
