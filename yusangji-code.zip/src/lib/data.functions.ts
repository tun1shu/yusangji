import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { z } from "zod";

function getPublicSupabase() {
  const url = process.env['SUPABASE_URL']!;
  const key = process.env['SUPABASE_PUBLISHABLE_KEY']!;
  return createClient<Database>(url, key, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const listFishSpecies = createServerFn({ method: "GET" }).handler(async () => {
  const supabase = getPublicSupabase();
  const { data, error } = await supabase
    .from("fish_species")
    .select("*")
    .order("difficulty", { ascending: true })
    .order("name", { ascending: true });
  if (error) throw error;
  return data ?? [];
});

export const getFishSpecies = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const supabase = getPublicSupabase();
    const { data: fish, error } = await supabase
      .from("fish_species")
      .select("*")
      .eq("id", data.id)
      .single();
    if (error) throw error;
    return fish;
  });

export const listCultureArticles = createServerFn({ method: "GET" }).handler(async () => {
  const supabase = getPublicSupabase();
  const { data, error } = await supabase
    .from("culture_articles")
    .select("*")
    .order("order_index", { ascending: true });
  if (error) throw error;
  return data ?? [];
});

export const getCultureArticle = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => z.object({ slug: z.string() }).parse(input))
  .handler(async ({ data }) => {
    const supabase = getPublicSupabase();
    const { data: article, error } = await supabase
      .from("culture_articles")
      .select("*")
      .eq("slug", data.slug)
      .single();
    if (error) throw error;
    return article;
  });

export const listQuizQuestions = createServerFn({ method: "GET" })
  .inputValidator(
    (input: unknown) =>
      z
        .object({
          limit: z.number().min(1).max(50).default(10),
          difficulty: z.string().optional(),
        })
        .parse(input)
  )
  .handler(async ({ data }) => {
    const supabase = getPublicSupabase();
    let query = supabase.from("quiz_questions").select("*");
    if (data.difficulty) query = query.eq("difficulty", data.difficulty);
    const { data: rows, error } = await query.order("created_at", { ascending: true }).limit(data.limit);
    if (error) throw error;
    return rows ?? [];
  });
