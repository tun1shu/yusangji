-- 角色枚举
CREATE TYPE public.app_role AS ENUM ('admin', 'editor');

-- 通用更新时间触发器
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- 用户资料
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nickname text,
  avatar_url text,
  grade text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own profile" ON public.profiles FOR ALL TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 用户角色（先建表，再补函数和策略）
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;

-- 安全角色校验函数（SECURITY DEFINER，绕过 RLS 防止递归）
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- 为用户角色表启用 RLS 并添加策略
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage roles" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- 鱼类条目
CREATE TABLE public.fish_species (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  scientific_name text,
  aliases text[],
  description text,
  habitat text,
  diet text,
  fun_facts text[],
  image_url text,
  category text,
  difficulty text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.fish_species TO anon;
GRANT SELECT ON public.fish_species TO authenticated;
GRANT ALL ON public.fish_species TO service_role;
ALTER TABLE public.fish_species ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read fish" ON public.fish_species FOR SELECT USING (true);
CREATE POLICY "Admins and editors can manage fish" ON public.fish_species FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role) OR public.has_role(auth.uid(), 'editor'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role) OR public.has_role(auth.uid(), 'editor'::public.app_role));
CREATE TRIGGER update_fish_species_updated_at BEFORE UPDATE ON public.fish_species FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 文化文章
CREATE TABLE public.culture_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  summary text,
  content text,
  cover_url text,
  category text,
  order_index int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.culture_articles TO anon;
GRANT SELECT ON public.culture_articles TO authenticated;
GRANT ALL ON public.culture_articles TO service_role;
ALTER TABLE public.culture_articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read articles" ON public.culture_articles FOR SELECT USING (true);
CREATE POLICY "Admins and editors can manage articles" ON public.culture_articles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role) OR public.has_role(auth.uid(), 'editor'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role) OR public.has_role(auth.uid(), 'editor'::public.app_role));
CREATE TRIGGER update_culture_articles_updated_at BEFORE UPDATE ON public.culture_articles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 题库
CREATE TABLE public.quiz_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  options text[] NOT NULL,
  correct_index int NOT NULL,
  explanation text,
  related_fish_id uuid REFERENCES public.fish_species(id) ON DELETE SET NULL,
  difficulty text,
  category text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.quiz_questions TO anon;
GRANT SELECT ON public.quiz_questions TO authenticated;
GRANT ALL ON public.quiz_questions TO service_role;
ALTER TABLE public.quiz_questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read quiz questions" ON public.quiz_questions FOR SELECT USING (true);
CREATE POLICY "Admins and editors can manage quiz" ON public.quiz_questions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role) OR public.has_role(auth.uid(), 'editor'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role) OR public.has_role(auth.uid(), 'editor'::public.app_role));

-- 收藏夹
CREATE TABLE public.user_favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  target_id uuid NOT NULL,
  target_type text NOT NULL CHECK (target_type IN ('fish','article')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, target_id, target_type)
);
GRANT SELECT, INSERT, DELETE ON public.user_favorites TO authenticated;
GRANT ALL ON public.user_favorites TO service_role;
ALTER TABLE public.user_favorites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own favorites" ON public.user_favorites FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 打卡
CREATE TABLE public.check_ins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  checked_in_at date NOT NULL DEFAULT CURRENT_DATE,
  note text,
  UNIQUE (user_id, checked_in_at)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.check_ins TO authenticated;
GRANT ALL ON public.check_ins TO service_role;
ALTER TABLE public.check_ins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own check-ins" ON public.check_ins FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 闯关记录
CREATE TABLE public.quiz_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  score int NOT NULL,
  total int NOT NULL,
  answers jsonb NOT NULL DEFAULT '[]'::jsonb,
  completed_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.quiz_attempts TO authenticated;
GRANT ALL ON public.quiz_attempts TO service_role;
ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read own attempts" ON public.quiz_attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own attempts" ON public.quiz_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- 示例鱼类数据
INSERT INTO public.fish_species (name, scientific_name, aliases, description, habitat, diet, fun_facts, image_url, category, difficulty) VALUES
('草鱼', 'Ctenopharyngodon idella', ARRAY['鲩鱼','草鲩'], '草鱼是中国四大家鱼之一，以水草为食，体型修长，肉质鲜美。', '淡水湖泊、河流、池塘', '水草、藻类、浮萍', ARRAY['草鱼每天能吃相当于体重一半的水草','草鱼帮助清理池塘杂草，是桑基鱼塘的重要角色'], 'https://placehold.co/600x400/4ade80/ffffff?text=草鱼', '家鱼', 'easy'),
('鲫鱼', 'Carassius auratus', ARRAY['鲫瓜子'], '鲫鱼体型小巧，适应性强，常见于中国淡水水域，是桑基鱼塘混养的好伙伴。', '池塘、河沟、湖泊', '藻类、有机碎屑、小型水生动物', ARRAY['鲫鱼耐寒，冬天也能活跃','传说鲫鱼是“水中清洁工”'], 'https://placehold.co/600x400/60a5fa/ffffff?text=鲫鱼', '家鱼', 'easy'),
('鲤鱼', 'Cyprinus carpio', ARRAY['鲤拐子'], '鲤鱼体色金黄，象征吉祥，在中国文化中寓意“鲤鱼跃龙门”。', '河流、湖泊、池塘', '底栖动物、水草、藻类', ARRAY['鲤鱼能活到20岁以上','古代科举时，鲤鱼是好运的象征'], 'https://placehold.co/600x400/f59e0b/ffffff?text=鲤鱼', '家鱼', 'easy'),
('青鱼', 'Mylopharyngodon piceus', ARRAY['黑鲩','螺蛳青'], '青鱼体型大，喜食螺蛳、蚌类，是四大家鱼中的“大力士”。', '深水湖泊、河流', '螺蛳、蚌、蚬', ARRAY['青鱼喉咙里有“咽喉齿”可以咬碎硬壳','一条大青鱼可以长到一米多长'], 'https://placehold.co/600x400/3b82f6/ffffff?text=青鱼', '家鱼', 'medium'),
('鳜鱼', 'Siniperca chuatsi', ARRAY['桂鱼','花鲫鱼'], '鳜鱼肉质细嫩、刺少，是中国传统的名贵淡水鱼。', '清澈的江河、湖泊', '小鱼、小虾', ARRAY['鳜鱼捕食凶猛，被称为“水中老虎”','“西塞山前白鹭飞，桃花流水鳜鱼肥”写的就是它'], 'https://placehold.co/600x400/a855f7/ffffff?text=鳜鱼', '名特优', 'medium');

-- 示例文化文章
INSERT INTO public.culture_articles (title, slug, summary, content, cover_url, category, order_index) VALUES
('什么是桑基鱼塘？', 'what-is-mulberry-fish-pond', '桑基鱼塘是一种古老的生态循环农业模式：塘基种桑、桑叶养蚕、蚕沙喂鱼、塘泥肥桑。', '桑基鱼塘是中国南方地区，特别是珠江三角洲和太湖流域流传千年的生态农业智慧。它的基本结构是在鱼塘周围或塘基上种植桑树，桑叶用来养蚕；蚕排出的蚕沙（蚕粪和残叶）投入鱼塘喂鱼；鱼的排泄物和塘泥又成为桑树的肥料，形成一个“桑—蚕—鱼—泥—桑”的良性循环。', 'https://placehold.co/800x400/22c55e/ffffff?text=桑基鱼塘', '生态循环', 1),
('桑基鱼塘的历史', 'history-of-mulberry-fish-pond', '从唐宋到明清，桑基鱼塘见证了江南农业与丝绸贸易的繁荣。', '早在唐代，江南地区就开始在池塘周围种植桑树。到了明清时期，珠江三角洲的“桑基鱼塘”已非常成熟，并与丝绸出口贸易紧密结合。这种模式不仅提高了土地利用率，还减少了化肥使用，是古代可持续农业的典范。', 'https://placehold.co/800x400/14b8a6/ffffff?text=历史', '历史', 2),
('塘泥养桑的秘密', 'pond-mud-for-mulberry', '鱼塘淤泥富含养分，是桑树最喜欢的天然肥料。', '鱼在水中游动、摄食和排泄，会产生大量有机物。这些有机物沉积到塘底形成淤泥。每年冬季或干塘时，农民会把塘泥挖出来铺在桑树根部。塘泥中的氮、磷、钾和有机质能促进桑树生长，桑叶更茂盛，蚕宝宝吃得更饱，吐出的丝也更优质。', 'https://placehold.co/800x400/d97706/ffffff?text=塘泥养桑', '科学原理', 3);

-- 示例 quiz 题目
INSERT INTO public.quiz_questions (question, options, correct_index, explanation, difficulty, category) VALUES
('桑基鱼塘中，桑叶主要用来做什么？', ARRAY['直接喂鱼','养蚕','做肥料','盖房子'], 1, '桑叶是蚕的主要食物，蚕沙再用来喂鱼。', 'easy', '桑基鱼塘'),
('草鱼最喜欢吃什么？', ARRAY['小鱼','螺蛳','水草','米饭'], 2, '草鱼以水草、藻类为主食，因此得名“草鱼”。', 'easy', '鱼类知识'),
('“鲤鱼跃龙门”寓意什么？', ARRAY['好运、高升','游泳很快','喜欢吃龙门','冬天冬眠'], 0, '在中国传统文化中，鲤鱼跃龙门象征飞黄腾达、考试高中。', 'easy', '鱼类文化'),
('青鱼为什么能咬碎螺蛳？', ARRAY['牙齿锋利','咽喉齿强壮','嘴巴大','舌头有力'], 1, '青鱼喉咙里有坚硬的“咽喉齿”，可以压碎螺蛳和蚌壳。', 'medium', '鱼类知识'),
('桑基鱼塘的生态循环顺序正确的是？', ARRAY['桑→蚕→鱼→泥→桑','鱼→桑→蚕→泥→鱼','泥→桑→鱼→蚕→泥','蚕→鱼→桑→泥→蚕'], 0, '桑叶养蚕，蚕沙喂鱼，塘泥肥桑，形成闭环。', 'medium', '桑基鱼塘');
