-- 先删除依赖 public.has_role 的策略
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins and editors can manage fish" ON public.fish_species;
DROP POLICY IF EXISTS "Admins and editors can manage articles" ON public.culture_articles;
DROP POLICY IF EXISTS "Admins and editors can manage quiz" ON public.quiz_questions;

-- 删除 public 模式下的旧函数
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);

-- 创建内部辅助模式
CREATE SCHEMA IF NOT EXISTS auth_helpers;

-- 在内部模式重建 has_role
CREATE OR REPLACE FUNCTION auth_helpers.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = auth_helpers, public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- 仅允许已登录用户通过 RLS 策略间接调用
GRANT USAGE ON SCHEMA auth_helpers TO authenticated;
GRANT EXECUTE ON FUNCTION auth_helpers.has_role(uuid, public.app_role) TO authenticated;

-- 重新创建 RLS 策略，引用 auth_helpers.has_role
CREATE POLICY "Admins can manage roles" ON public.user_roles FOR ALL TO authenticated USING (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins and editors can manage fish" ON public.fish_species FOR ALL TO authenticated USING (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role) OR auth_helpers.has_role(auth.uid(), 'editor'::public.app_role)) WITH CHECK (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role) OR auth_helpers.has_role(auth.uid(), 'editor'::public.app_role));

CREATE POLICY "Admins and editors can manage articles" ON public.culture_articles FOR ALL TO authenticated USING (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role) OR auth_helpers.has_role(auth.uid(), 'editor'::public.app_role)) WITH CHECK (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role) OR auth_helpers.has_role(auth.uid(), 'editor'::public.app_role));

CREATE POLICY "Admins and editors can manage quiz" ON public.quiz_questions FOR ALL TO authenticated USING (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role) OR auth_helpers.has_role(auth.uid(), 'editor'::public.app_role)) WITH CHECK (auth_helpers.has_role(auth.uid(), 'admin'::public.app_role) OR auth_helpers.has_role(auth.uid(), 'editor'::public.app_role));
