
UPDATE public.fish_species SET
  scientific_name = 'Mylopharyngodon piceus',
  aliases = ARRAY['黑鲩','螺蛳青'],
  description = '四大家鱼之一，体型圆筒状，鳞片与鱼鳍通体青黑，腹部灰白；头尖无须，是四大家鱼中体型最大的一种，野生个体可达百斤以上。性情安静，生长周期长，4-5 年才性成熟。肉质紧实、刺少，适合红烧、熏鱼与鱼丸。',
  habitat = '水体底层，喜深水、淤泥多、螺蚌丰富的区域',
  diet = '肉食性：咽喉齿坚硬，专咬碎螺蛳、河蚌、蚬；鱼苗期吃浮游动物',
  fun_facts = ARRAY['咽喉齿能像钳子一样夹碎螺壳，所以又叫“螺蛳青”。','在桑基鱼塘的立体混养中负责“打扫水底”，控制底栖螺类。','高蛋白，传统上被视为体虚滋补的食材。'],
  image_url = '/__l5e/assets-v1/ac53adf9-8056-4dc1-863c-5518bc4ea220/qingyu.jpg',
  category = '四大家鱼', difficulty = 'medium'
WHERE name = '青鱼';

UPDATE public.fish_species SET
  scientific_name = 'Ctenopharyngodon idella',
  aliases = ARRAY['鲩鱼','草混子'],
  description = '四大家鱼之一，圆筒身形，体色茶黄、背部草绿，头部宽钝，鳞片比青鱼浅，很好区分。活泼好动、集群觅食，生长速度快，2 年可长 5-8 斤。肉质细嫩，适合水煮鱼、烤鱼、清蒸与鱼片。',
  habitat = '水体中下层，常在近岸水草区活动，经常上浮吃草',
  diet = '纯草食性：幼鱼吃藻类小虫，10cm 以上只吃水草、芦苇、浮萍、菜叶',
  fun_facts = ARRAY['被称为“水中除草机”，能帮池塘清理疯长的水草。','它的粪便可以肥水，培育浮游生物供鲢鳙取食，是混养链条的关键一环。','肉质易消化，老少皆宜，是我国食用最广泛的淡水鱼之一。'],
  image_url = '/__l5e/assets-v1/27d3a3d5-6666-43d9-b75b-f2c21c576036/caoyu.jpg',
  category = '四大家鱼', difficulty = 'easy'
WHERE name = '草鱼';

INSERT INTO public.fish_species (name, scientific_name, aliases, description, habitat, diet, fun_facts, image_url, category, difficulty)
SELECT '鲢鱼', 'Hypophthalmichthys molitrix', ARRAY['白鲢','跳鲢'],
  '四大家鱼之一，通体银白、鳞片细小，头小（头长仅占体长约 1/4），腹部有一条贯穿全长的明显棱脊。性子极急躁，受惊会疯狂跳跃，俗称“跳鲢”；生长极快，一年即可上市。缺点是肌间细刺多、肉质偏松散。',
  '水体上层',
  '滤食性：用细密鳃耙过滤浮游植物，专吃蓝藻、绿藻',
  ARRAY['是治理水体富营养化、抑制蓝藻水华的“生态清道夫”，湖泊生态修复常用它。','没有咀嚼牙齿，其实并不吃水草，只能滤食微小浮游生物。','低脂肪高蛋白，适合减脂人群。'],
  '/__l5e/assets-v1/2e26895f-3e86-4fdc-9660-a0e2c826deee/bailian.jpg', '四大家鱼', 'easy'
WHERE NOT EXISTS (SELECT 1 FROM public.fish_species WHERE name = '鲢鱼');

INSERT INTO public.fish_species (name, scientific_name, aliases, description, habitat, diet, fun_facts, image_url, category, difficulty)
SELECT '鳙鱼', 'Hypophthalmichthys nobilis', ARRAY['花鲢','胖头鱼'],
  '四大家鱼之一，身体灰黑并布满不规则黑斑，最大特征是大头，头部约占体长 1/3；腹部棱脊短，只在后半段。性格温顺、行动缓慢，几乎不跳，2-3 年成熟，大个体可达 20 斤以上。鱼头肥美胶质多，是剁椒鱼头、鱼头豆腐汤的招牌食材。',
  '水体中上层',
  '滤食性：鳃耙较粗，主要吃浮游动物（水蚤、轮虫），少量藻类',
  ARRAY['分辨口诀：头大带黑斑就是鳙鱼，头小通体雪白就是白鲢。','鱼头富含胶原蛋白，是“剁椒鱼头”的主角。','和白鲢分工不同：白鲢控藻类，鳙鱼控浮游动物。'],
  '/__l5e/assets-v1/f3daf697-8d78-4f8a-9562-88662d266f3d/yongyu.jpg', '四大家鱼', 'easy'
WHERE NOT EXISTS (SELECT 1 FROM public.fish_species WHERE name = '鳙鱼');
